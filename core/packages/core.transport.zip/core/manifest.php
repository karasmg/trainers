<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => '93c1b906bb3bd0a37c6ec4132d964ef2',
      'native_key' => 'core',
      'filename' => 'modNamespace/2e866d89967a924f1e79f90a721dcb75.vehicle',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modWorkspace',
      'guid' => '8e68f0252f03f26244b993b6016c5cf9',
      'native_key' => 1,
      'filename' => 'modWorkspace/3bbc3f705aaa2df807693888d82d6703.vehicle',
    ),
    2 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modTransportProvider',
      'guid' => '24a9c7996bded6a4668d58a8bd08cb1e',
      'native_key' => 1,
      'filename' => 'modTransportProvider/bf9c8f852b4caa71539fa5d194124882.vehicle',
    ),
    3 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => '13b368407f1d343df0cdcbd89ff5a82b',
      'native_key' => 'topnav',
      'filename' => 'modMenu/2dcc44cf894f2b556af0594c584a308c.vehicle',
    ),
    4 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => 'fed9d441ca65dc4631777d7401951da8',
      'native_key' => 'usernav',
      'filename' => 'modMenu/9e43a74bd7efb9862bf9b71948f732d5.vehicle',
    ),
    5 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modContentType',
      'guid' => 'b8cc2a02f26c090fab1f498cf9a6a63c',
      'native_key' => 1,
      'filename' => 'modContentType/39d62e03427b12efa440034d7f4f019b.vehicle',
    ),
    6 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modContentType',
      'guid' => 'a64c0989d00a28efd9587ca0fb617f00',
      'native_key' => 2,
      'filename' => 'modContentType/4fed240bc74ca9940c8d3286d3527424.vehicle',
    ),
    7 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modContentType',
      'guid' => 'd0d436025d92b6ef06e91b742d719d95',
      'native_key' => 3,
      'filename' => 'modContentType/36843810dc3e0fd91c20f2c93479a057.vehicle',
    ),
    8 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modContentType',
      'guid' => '7bc19b8331441590820925cbcc175780',
      'native_key' => 4,
      'filename' => 'modContentType/ac1393ba92248e8999348fab2edbcb40.vehicle',
    ),
    9 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modContentType',
      'guid' => '98c68a93f4be766e83f8b828a1e7df00',
      'native_key' => 5,
      'filename' => 'modContentType/842230e5b855bf44d5871ad8fe7e17aa.vehicle',
    ),
    10 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modContentType',
      'guid' => 'd22d52cf58e815d5a2b3624cd25d3801',
      'native_key' => 6,
      'filename' => 'modContentType/6b498d9bfdbc7037d4b76012d61dfebf.vehicle',
    ),
    11 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modContentType',
      'guid' => '74fc34852b7c36860a001a47fa1b9efd',
      'native_key' => 7,
      'filename' => 'modContentType/c684d5b93dfc8ec11b097da006cd9b04.vehicle',
    ),
    12 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modContentType',
      'guid' => '3169893c64f0bdd5bf96c1a76b31f84b',
      'native_key' => 8,
      'filename' => 'modContentType/d2abd551ffef87b68e7bcadf75a8168c.vehicle',
    ),
    13 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modClassMap',
      'guid' => 'fce2616427d7f0721e8f1c10d1064b81',
      'native_key' => NULL,
      'filename' => 'modClassMap/9c3188a228e8272741ac531aea3ee9ea.vehicle',
    ),
    14 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modClassMap',
      'guid' => '850e554c070c50793353037a1b18fce4',
      'native_key' => NULL,
      'filename' => 'modClassMap/ef0499fe211a1a3d742a3b02c5d05f9d.vehicle',
    ),
    15 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modClassMap',
      'guid' => '1bbb101ff513053062cb650df700a3b0',
      'native_key' => NULL,
      'filename' => 'modClassMap/a7c4c23aa40578fbcfb075879eb915f5.vehicle',
    ),
    16 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modClassMap',
      'guid' => '0fbfb9e07be913d8756c0e5518c1c9d4',
      'native_key' => NULL,
      'filename' => 'modClassMap/1d72765838e5e93728c79e9ef89d1a57.vehicle',
    ),
    17 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modClassMap',
      'guid' => 'ff1a8182302709c0d7930355c574482e',
      'native_key' => NULL,
      'filename' => 'modClassMap/661116f324290a64e5bfd29485eafca4.vehicle',
    ),
    18 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modClassMap',
      'guid' => '496b73b9a989b635699a37788acffdf3',
      'native_key' => NULL,
      'filename' => 'modClassMap/2c6c084e1d882f8a7b2f14b588d1c6bd.vehicle',
    ),
    19 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modClassMap',
      'guid' => '7f2707bfe7c4b0996e2b89670b624087',
      'native_key' => NULL,
      'filename' => 'modClassMap/e2cc49335d314be3d02a65afb0cd1bab.vehicle',
    ),
    20 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modClassMap',
      'guid' => '0b4fdd4ffbb10a620fce7a5a582fb0cd',
      'native_key' => NULL,
      'filename' => 'modClassMap/550e3f6926bab888fd3e64c6f0823c13.vehicle',
    ),
    21 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modClassMap',
      'guid' => '35bf36e49ff548569af6e5c958a1aa51',
      'native_key' => NULL,
      'filename' => 'modClassMap/fe468209021081f35bb21b4736c6a3ab.vehicle',
    ),
    22 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '952447a499ddfdb6fa579bf77f7288bf',
      'native_key' => 'OnPluginEventBeforeSave',
      'filename' => 'modEvent/2d2087ee78944664722cfa4502b00132.vehicle',
    ),
    23 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '86eb06ad1a289645d4d51f1399d36dd2',
      'native_key' => 'OnPluginEventSave',
      'filename' => 'modEvent/a4e60255e172c73b302d7cd76a77e78c.vehicle',
    ),
    24 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '1f8dc55366fe844b515da95b1f6da48e',
      'native_key' => 'OnPluginEventBeforeRemove',
      'filename' => 'modEvent/3dd46f2fff435d6348169e7a16247ade.vehicle',
    ),
    25 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'edbe5bcb457a465aadea87553f563881',
      'native_key' => 'OnPluginEventRemove',
      'filename' => 'modEvent/7b33fde9fe3d1a1939a66efb46ace805.vehicle',
    ),
    26 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '5783bbff54658edfc7a7f9858aaa847f',
      'native_key' => 'OnResourceGroupSave',
      'filename' => 'modEvent/1b764f919174b6c683256f09cbcfec4f.vehicle',
    ),
    27 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '85ca1c6f91a6dff14b89f33d6488221c',
      'native_key' => 'OnResourceGroupBeforeSave',
      'filename' => 'modEvent/279a4610b0500f30e336c9b017ebe3c8.vehicle',
    ),
    28 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'db00094a829cebc53550c256f3590bae',
      'native_key' => 'OnResourceGroupRemove',
      'filename' => 'modEvent/0669a7055414fa36a14324667562a0ee.vehicle',
    ),
    29 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '949895acefe2e2f778952a2e5b06c6b3',
      'native_key' => 'OnResourceGroupBeforeRemove',
      'filename' => 'modEvent/46c19571d4d05e04345c43d997879e83.vehicle',
    ),
    30 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'a0e708d592a97febcb909106978be358',
      'native_key' => 'OnSnippetBeforeSave',
      'filename' => 'modEvent/5766aab1858185976271cd402ee2b883.vehicle',
    ),
    31 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '6b001bd387b2fa00a72480874b149c03',
      'native_key' => 'OnSnippetSave',
      'filename' => 'modEvent/6334132823a00f0eb0b480cafd52ee4e.vehicle',
    ),
    32 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '2ab01d8e6198617af59d59270a945e90',
      'native_key' => 'OnSnippetBeforeRemove',
      'filename' => 'modEvent/415751f20e93a50757fe06935adec4a8.vehicle',
    ),
    33 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'a1dbd076b6f7d158083db87e47a99ab9',
      'native_key' => 'OnSnippetRemove',
      'filename' => 'modEvent/a3b8c885a0d7924ed0f8d0acdbfa952c.vehicle',
    ),
    34 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'ec0f9be35ff18d2264fb9564fb5e77e0',
      'native_key' => 'OnSnipFormPrerender',
      'filename' => 'modEvent/6ddb2f7feebf88ffdd86cadc60953cb6.vehicle',
    ),
    35 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '49e95c7a4295625a58f374b7eb4aee25',
      'native_key' => 'OnSnipFormRender',
      'filename' => 'modEvent/464cb87594415e3689cb1ad81fed45ce.vehicle',
    ),
    36 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'd7a4b59a71db0fe6372c615f0a3e9894',
      'native_key' => 'OnBeforeSnipFormSave',
      'filename' => 'modEvent/897f3041ebb03acad0c6970dd1b7c087.vehicle',
    ),
    37 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '4271a8e0fbd51bb7cf3378d3a58bbfc8',
      'native_key' => 'OnSnipFormSave',
      'filename' => 'modEvent/f6e19053ce8a89a2b4370ef3815b6b89.vehicle',
    ),
    38 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '5e3a7d30b2c80977d5f1bc9a96b8f8fe',
      'native_key' => 'OnBeforeSnipFormDelete',
      'filename' => 'modEvent/eae9ea5aaccd35cf0e5e12953f9cbe85.vehicle',
    ),
    39 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '6714108de6a5dda324a999a4574b6bfb',
      'native_key' => 'OnSnipFormDelete',
      'filename' => 'modEvent/c0ac3f09217c029076c1c6010addb18b.vehicle',
    ),
    40 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '8544636f569b6f2ca82c11a3cc1943b3',
      'native_key' => 'OnTemplateBeforeSave',
      'filename' => 'modEvent/afcb79068f677acffb09733bc5c388e6.vehicle',
    ),
    41 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '4b73e8568c79703a3062484097f6da6a',
      'native_key' => 'OnTemplateSave',
      'filename' => 'modEvent/ca83c73bb3cb07215bae5c14c1940cce.vehicle',
    ),
    42 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'b3e5dde90c1b761be1d5afa89385958c',
      'native_key' => 'OnTemplateBeforeRemove',
      'filename' => 'modEvent/dcea5ad29581a9a01cfbb5907f913188.vehicle',
    ),
    43 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '36fe50ce53aa8f49e9112ecebbf86e58',
      'native_key' => 'OnTemplateRemove',
      'filename' => 'modEvent/f587b9518d5d260de8f36a16ec02bcfb.vehicle',
    ),
    44 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'e0d5f7ef2d1fc8694baa8dc560376800',
      'native_key' => 'OnTempFormPrerender',
      'filename' => 'modEvent/65a6ffa03ef5b02fa09ab89f22cc9f97.vehicle',
    ),
    45 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '68378dd9626f1413cfa0e7b333e9378c',
      'native_key' => 'OnTempFormRender',
      'filename' => 'modEvent/760f9a73132cbebd3d5de46ac7db4711.vehicle',
    ),
    46 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'ada0fc79db8580a57782cf5444c9edfe',
      'native_key' => 'OnBeforeTempFormSave',
      'filename' => 'modEvent/5c41d4508dd5376c45b85a179a6469ac.vehicle',
    ),
    47 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '84288fa468e2a0edd7961180635cc41a',
      'native_key' => 'OnTempFormSave',
      'filename' => 'modEvent/2452aab826e2afbcd7c6ffee1980a04a.vehicle',
    ),
    48 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '09ac451d9041577d38e538f9361a34f8',
      'native_key' => 'OnBeforeTempFormDelete',
      'filename' => 'modEvent/25c71f62759363495f7e2882e8eb2980.vehicle',
    ),
    49 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'bb0135745e0653f01ca51c1ca78dc9d4',
      'native_key' => 'OnTempFormDelete',
      'filename' => 'modEvent/650edeb1ae59407cddceb1663ea9fd17.vehicle',
    ),
    50 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '1587cc6030933178541876e0df6f2818',
      'native_key' => 'OnTemplateVarBeforeSave',
      'filename' => 'modEvent/9a73171965fd7bf67981ff4717aabb4b.vehicle',
    ),
    51 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '2dba3ef9f0a42e2f5d611415d5234637',
      'native_key' => 'OnTemplateVarSave',
      'filename' => 'modEvent/9a6eb6100ab4a08839316fac50684260.vehicle',
    ),
    52 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '6d1d04783ffb4aee6091c49b17b21831',
      'native_key' => 'OnTemplateVarBeforeRemove',
      'filename' => 'modEvent/f87e1f67c2f9c79e4fa2f6267b5ce6ba.vehicle',
    ),
    53 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'd5bceba7b08b857582c6b9a1ab022ae3',
      'native_key' => 'OnTemplateVarRemove',
      'filename' => 'modEvent/3d9f47cc9488b9a00d3cb71b3a71d4c9.vehicle',
    ),
    54 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '96fc60cffef3f8ec8ed77e900cf2a5a6',
      'native_key' => 'OnTVFormPrerender',
      'filename' => 'modEvent/e7646e58b0428533787a9872440469f1.vehicle',
    ),
    55 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '76bbc81a2b3e168225bdf6e7b1eea530',
      'native_key' => 'OnTVFormRender',
      'filename' => 'modEvent/a4f2448db4cdf919d9a08dd21d46c5b0.vehicle',
    ),
    56 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'afe86afe91068008b14df10c82a7269a',
      'native_key' => 'OnBeforeTVFormSave',
      'filename' => 'modEvent/b2a79b9febd5804a65d588791556342b.vehicle',
    ),
    57 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'e7a1dfc91b9888c5797690c695342d8d',
      'native_key' => 'OnTVFormSave',
      'filename' => 'modEvent/12761e438d479e6b21a3f46595e536e6.vehicle',
    ),
    58 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '3c587735387958b496a7bd37b06634d7',
      'native_key' => 'OnBeforeTVFormDelete',
      'filename' => 'modEvent/8e4a49304fed9f05238dc30ae0c3ea03.vehicle',
    ),
    59 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '2a4772014e04f84d48adddb9fb4cb64c',
      'native_key' => 'OnTVFormDelete',
      'filename' => 'modEvent/d785dfcf42aac4cba3395e3bb76c7af0.vehicle',
    ),
    60 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '60509e8555f75283c6a377c847c2b6b6',
      'native_key' => 'OnTVInputRenderList',
      'filename' => 'modEvent/9faa4b1e54bc0c83d351b811fa8de072.vehicle',
    ),
    61 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'a96bab7923f71908542631b285902554',
      'native_key' => 'OnTVInputPropertiesList',
      'filename' => 'modEvent/d7c0f6740820a913f64dad0adf977cf2.vehicle',
    ),
    62 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '62731392cbde7a2b764ea5165d443746',
      'native_key' => 'OnTVOutputRenderList',
      'filename' => 'modEvent/9ead0d77a4792356c9f9707a7d4e6d18.vehicle',
    ),
    63 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '52e0f736292550dad2e7360a2c42cfe2',
      'native_key' => 'OnTVOutputRenderPropertiesList',
      'filename' => 'modEvent/8b593d3ab4387ff02e6a027809f4a58e.vehicle',
    ),
    64 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '77ee1eb9afed596294e9e9886ea2f0bf',
      'native_key' => 'OnUserGroupBeforeSave',
      'filename' => 'modEvent/751a528d1bab15439b67acb236fdcc73.vehicle',
    ),
    65 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '4d959c981ec3d09a117abeb3e243f23f',
      'native_key' => 'OnUserGroupSave',
      'filename' => 'modEvent/cd7bb284589c6ae30c8813b3c373a2e7.vehicle',
    ),
    66 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '046efdd986f2199e677e827aaec2c13a',
      'native_key' => 'OnUserGroupBeforeRemove',
      'filename' => 'modEvent/ec9b8332342a8f3802dcae90d3f33ad9.vehicle',
    ),
    67 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'ca72d5e26dc20f7864c77a1d12c6fd6c',
      'native_key' => 'OnUserGroupRemove',
      'filename' => 'modEvent/d69d037723b6bab1a011c186be97a605.vehicle',
    ),
    68 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '326a9917a2705036bb308811315f6e2a',
      'native_key' => 'OnBeforeUserGroupFormSave',
      'filename' => 'modEvent/c439b31b5d0cfdf165cc1f83c267fa74.vehicle',
    ),
    69 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'c2773dde3fba37e17d961735d98c1679',
      'native_key' => 'OnUserGroupFormSave',
      'filename' => 'modEvent/e137d366a98ebbf26b7162e8bbe9edf6.vehicle',
    ),
    70 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'e894be04d1fe7a9749923d1333c42007',
      'native_key' => 'OnBeforeUserGroupFormRemove',
      'filename' => 'modEvent/21468bd7fd3dd1a7101d00619bdb10a3.vehicle',
    ),
    71 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '87865a9092d1fbb705a2148a108a5246',
      'native_key' => 'OnBeforeUserGroupFormRemove',
      'filename' => 'modEvent/df30eb5388d3e23bc6bda3057383412b.vehicle',
    ),
    72 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '4eac95ca6191c92a8d4a8b25849ff6d3',
      'native_key' => 'OnDocFormPrerender',
      'filename' => 'modEvent/3e2eed5a924f864259e294e2702cf332.vehicle',
    ),
    73 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '7728aeca9db304e52e60ba60487a548e',
      'native_key' => 'OnDocFormRender',
      'filename' => 'modEvent/2da2e9cd3ee265b72f601ad76175139a.vehicle',
    ),
    74 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '782c56e075659e312895101d5f7796ed',
      'native_key' => 'OnBeforeDocFormSave',
      'filename' => 'modEvent/b05cb88e1605f6a9593cc8648e8c4be8.vehicle',
    ),
    75 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'a9e4a22693c7575595b9c6ab554479f5',
      'native_key' => 'OnDocFormSave',
      'filename' => 'modEvent/1a902d46007f5e9853b26ab4d8a4c61d.vehicle',
    ),
    76 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '05f2cdd17a88ac48f635630ffd9e2e45',
      'native_key' => 'OnBeforeDocFormDelete',
      'filename' => 'modEvent/5087611458567724e283a1b82907b0d8.vehicle',
    ),
    77 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '918ad437fd3b39cbc996eb8c4ca23bd5',
      'native_key' => 'OnDocFormDelete',
      'filename' => 'modEvent/03b0792500ff5870d61cafc4479047a6.vehicle',
    ),
    78 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '59bc326b21f176fa010439c28a30dbed',
      'native_key' => 'OnDocPublished',
      'filename' => 'modEvent/d17e4f6b70f86969bcd1fc1387d8acd1.vehicle',
    ),
    79 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '6a71d9676721d9948caf2bf7d0cedb3a',
      'native_key' => 'OnDocUnPublished',
      'filename' => 'modEvent/92f54033ae4a0429ae6648c1a34588ed.vehicle',
    ),
    80 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'a761d8b1a7d5a6cc12b7507184e414aa',
      'native_key' => 'OnBeforeEmptyTrash',
      'filename' => 'modEvent/22c021c0cf935cfc2098cd1c8ff0862d.vehicle',
    ),
    81 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '3de3df132067dfe71d682d9158e8301c',
      'native_key' => 'OnEmptyTrash',
      'filename' => 'modEvent/70bd50d3625b58d0d61bb97f590be0da.vehicle',
    ),
    82 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '541cf7ab1681d9efa4cbc56bb8e40fbc',
      'native_key' => 'OnResourceTVFormPrerender',
      'filename' => 'modEvent/4ed4a8abe8f243994ea3c2cbb69adcdf.vehicle',
    ),
    83 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '1eb9d6afc233ddd34f27c5fa4c44df76',
      'native_key' => 'OnResourceTVFormRender',
      'filename' => 'modEvent/95b243bd79ac9af8b1031ce97092141a.vehicle',
    ),
    84 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '85e725c07c4c21ed2c0b261e039e5d46',
      'native_key' => 'OnResourceAutoPublish',
      'filename' => 'modEvent/19f6d72a6e7bfa8020aac0d3265aed24.vehicle',
    ),
    85 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '6b515114b4f9939056700e774fb6f3c0',
      'native_key' => 'OnResourceDelete',
      'filename' => 'modEvent/c342044cffd67df5d3001367cfc1da57.vehicle',
    ),
    86 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'e1eb17344ef2bce02005ddc37a425407',
      'native_key' => 'OnResourceUndelete',
      'filename' => 'modEvent/dd8b474529f080cc35ba8b3c64c15081.vehicle',
    ),
    87 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '267fffa8e6af92be2800022391850009',
      'native_key' => 'OnResourceBeforeSort',
      'filename' => 'modEvent/efd7d16423b411e3e8a3bf52e12eeed9.vehicle',
    ),
    88 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '68eae776d5f75f4df1543cef96511423',
      'native_key' => 'OnResourceSort',
      'filename' => 'modEvent/2708459eaa5206d3f4ec4e8f542da325.vehicle',
    ),
    89 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'a6182939373dc5090c223a5cab0a301e',
      'native_key' => 'OnResourceDuplicate',
      'filename' => 'modEvent/24e3a63ca810ccb0c28eaa2e3dac3375.vehicle',
    ),
    90 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'dfdd65e65dcbbc8b622e6d032a025bc5',
      'native_key' => 'OnResourceToolbarLoad',
      'filename' => 'modEvent/70b0f934909dde1b885f080823ea55bd.vehicle',
    ),
    91 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '336af5921dce3f894c84c469c23acaf1',
      'native_key' => 'OnResourceRemoveFromResourceGroup',
      'filename' => 'modEvent/13c8a92e8cae18736179b1c00f0f8dac.vehicle',
    ),
    92 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '78774f11dafba3a0670a4ac97930a5b7',
      'native_key' => 'OnResourceAddToResourceGroup',
      'filename' => 'modEvent/76d8469606d2e613f2991ed496c54b02.vehicle',
    ),
    93 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '2322cb8c1a6ec86b2e213d1091679e2a',
      'native_key' => 'OnRichTextEditorRegister',
      'filename' => 'modEvent/817cc20c4d6e0d3cf59ee50c2d5f6f65.vehicle',
    ),
    94 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '1ee2752bc4576998a966f5ad18bc54a7',
      'native_key' => 'OnRichTextEditorInit',
      'filename' => 'modEvent/1428cbf90ec9167eac216dbe68c8f326.vehicle',
    ),
    95 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'c92cd6c709ab7da2b655f600462d57be',
      'native_key' => 'OnRichTextBrowserInit',
      'filename' => 'modEvent/c4df71a930a040affceb2a271b11c875.vehicle',
    ),
    96 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'c57a9a0e4b367db5892fe05a2b04f2b2',
      'native_key' => 'OnWebLogin',
      'filename' => 'modEvent/86c03d9885f2575eee7d8bcf20308c87.vehicle',
    ),
    97 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '543f19c061a8254b5bd85695211e568d',
      'native_key' => 'OnBeforeWebLogout',
      'filename' => 'modEvent/919f1d957300de3c1008f8905d636dc7.vehicle',
    ),
    98 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '9a51979f0c15818105d71417aaeb82f3',
      'native_key' => 'OnWebLogout',
      'filename' => 'modEvent/133e30c48b02f9c541e3cf628d90dccd.vehicle',
    ),
    99 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '677064b3262f42121739269adbed9a15',
      'native_key' => 'OnManagerLogin',
      'filename' => 'modEvent/2229bdbc8664bee21d5a909ab42a0184.vehicle',
    ),
    100 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '58f8583b24878a4f8d18304649bf248e',
      'native_key' => 'OnBeforeManagerLogout',
      'filename' => 'modEvent/dcf89bc6451f6998c590738db84ef232.vehicle',
    ),
    101 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '3890bc7126e6fd19ecd227848518edb0',
      'native_key' => 'OnManagerLogout',
      'filename' => 'modEvent/a747c4dc3952d80e78455deedd2b86b4.vehicle',
    ),
    102 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '9bef32e37fbfca4034da70c110be2e98',
      'native_key' => 'OnBeforeWebLogin',
      'filename' => 'modEvent/78e87c98cad6a71ea0711fbb2270bc27.vehicle',
    ),
    103 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '585188648facb7766be8b59af628c237',
      'native_key' => 'OnWebAuthentication',
      'filename' => 'modEvent/196fdf2227a23a467e90cd3488a4b311.vehicle',
    ),
    104 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '0da3e516c93c6b502a2f396ba34941ff',
      'native_key' => 'OnBeforeManagerLogin',
      'filename' => 'modEvent/2853a0487a968dab8c7f265d10a4c2a2.vehicle',
    ),
    105 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '33465c1802754460c89367acaac3813d',
      'native_key' => 'OnManagerAuthentication',
      'filename' => 'modEvent/292d61bd7f0b07c8300cadf16093f6c5.vehicle',
    ),
    106 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '893728d5fc3fa6852b1f62e9c7ab7361',
      'native_key' => 'OnManagerLoginFormRender',
      'filename' => 'modEvent/3995b0bf96f9350b3127cff1dc319ac6.vehicle',
    ),
    107 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '734a78b5f3ee5587e0ce49879f4f95ce',
      'native_key' => 'OnManagerLoginFormPrerender',
      'filename' => 'modEvent/b6b11c7f2416a678111748fa97e4c7fa.vehicle',
    ),
    108 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '408687c769a26269a945c5fd488100a9',
      'native_key' => 'OnPageUnauthorized',
      'filename' => 'modEvent/d2d11facacf585a780af9dc3b90b9521.vehicle',
    ),
    109 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '1e7086e9287ff5aa55619a8ce1a0774e',
      'native_key' => 'OnUserFormPrerender',
      'filename' => 'modEvent/d9cfba77a1a1b04d40551590bad70202.vehicle',
    ),
    110 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '94ff293c6855a06e96affa7c55636fca',
      'native_key' => 'OnUserFormRender',
      'filename' => 'modEvent/a2062ce361cda3636ca3eed279571075.vehicle',
    ),
    111 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'ce0e40b1adc61872dd04205b83e122f3',
      'native_key' => 'OnBeforeUserFormSave',
      'filename' => 'modEvent/d9a757d74b678a162e6a8e10eeeabb46.vehicle',
    ),
    112 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '6cbfd6646d81c506e844b973812749e0',
      'native_key' => 'OnUserFormSave',
      'filename' => 'modEvent/7ee093a88fadff963591665b3422cdb6.vehicle',
    ),
    113 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'fccef4d998f7ec5d59370768aac7b5fb',
      'native_key' => 'OnBeforeUserFormDelete',
      'filename' => 'modEvent/bce53bc5bea78818b67ccb549c29edfe.vehicle',
    ),
    114 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '43adcce179b5d5ae23e1b550fd9509c5',
      'native_key' => 'OnUserFormDelete',
      'filename' => 'modEvent/4460a0564d5be04d82b58461d21dc827.vehicle',
    ),
    115 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '802d90bc9c427f2777366a98f059daed',
      'native_key' => 'OnUserNotFound',
      'filename' => 'modEvent/befe928768a0008863c0a69ac733e5b4.vehicle',
    ),
    116 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '3b17282464a2a6e96fff4614ba5f0d22',
      'native_key' => 'OnBeforeUserActivate',
      'filename' => 'modEvent/17924f6d978fe7474024bacccc554a0c.vehicle',
    ),
    117 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '2e09afad1354f6b92d46f567a8ff945e',
      'native_key' => 'OnUserActivate',
      'filename' => 'modEvent/8bad6a9426e1a99ec8c7affea45ee7cc.vehicle',
    ),
    118 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '58f062206f29076e58f89cf8a5d7176e',
      'native_key' => 'OnBeforeUserDeactivate',
      'filename' => 'modEvent/e9eec5c377208acdb6055491a8566307.vehicle',
    ),
    119 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '46d0bfe08e165a4c4dcae5157312e78c',
      'native_key' => 'OnUserDeactivate',
      'filename' => 'modEvent/a5adb6eaf05a4d56080779fcf9c37619.vehicle',
    ),
    120 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'eafee50a99ab793975658a653a99c75a',
      'native_key' => 'OnBeforeUserDuplicate',
      'filename' => 'modEvent/08c64a7c8a761d70641aa1f61789a82e.vehicle',
    ),
    121 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '0854c2f0c20accdcc6b8ef5a2c6da623',
      'native_key' => 'OnUserDuplicate',
      'filename' => 'modEvent/7e186053374521605225db665a57fa75.vehicle',
    ),
    122 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '1b34e535d41e4f39856871aec86df829',
      'native_key' => 'OnUserChangePassword',
      'filename' => 'modEvent/f2f03494322f454797af02548f134777.vehicle',
    ),
    123 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '1e87f383b9f349419e4547b8e3b43a08',
      'native_key' => 'OnUserBeforeRemove',
      'filename' => 'modEvent/b4e8ba28d1a9c171f2717ac0fbce8348.vehicle',
    ),
    124 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'ed8a72caf65f9f85760b5e3e29c11c8e',
      'native_key' => 'OnUserBeforeSave',
      'filename' => 'modEvent/51f216b12f4d6c3369ec972b807b531a.vehicle',
    ),
    125 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'acca105184982b5bd8ca2b742385bd45',
      'native_key' => 'OnUserSave',
      'filename' => 'modEvent/e711cbb6874ddf9330cdef6854e1ad36.vehicle',
    ),
    126 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'c04101106399e2b22eec41d0e6a5d0df',
      'native_key' => 'OnUserRemove',
      'filename' => 'modEvent/b10d8331320df53e262031bdf810e407.vehicle',
    ),
    127 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '547e267c94855b75800fe457ee8b8359',
      'native_key' => 'OnUserBeforeAddToGroup',
      'filename' => 'modEvent/506c0965e068094f559f31c680d042b8.vehicle',
    ),
    128 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'f4b9dcd818ccadc38ab738d7b2c1cc5c',
      'native_key' => 'OnUserAddToGroup',
      'filename' => 'modEvent/8552707d4b33d887acfe7d5c361f23f5.vehicle',
    ),
    129 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '76b249f35c3dc1d103a5582b89cd8d2b',
      'native_key' => 'OnUserBeforeRemoveFromGroup',
      'filename' => 'modEvent/bb3cf5f4a612d4a7ee1317822d420be5.vehicle',
    ),
    130 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'e997b5dd12b67626b2c233ed76040e80',
      'native_key' => 'OnUserRemoveFromGroup',
      'filename' => 'modEvent/01659c77e388d22cd2144dc7b5e98915.vehicle',
    ),
    131 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '0adf4a87bb4ce5d7bf76cc5b87ec5314',
      'native_key' => 'OnWebPagePrerender',
      'filename' => 'modEvent/ca5ed92832e92af0d363729c7faf1224.vehicle',
    ),
    132 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '643084ccc12d4bc1366529d4c4125136',
      'native_key' => 'OnBeforeCacheUpdate',
      'filename' => 'modEvent/210844aecfaa839138bb2ae18fa0c27a.vehicle',
    ),
    133 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'baa9fcd2e5f9dbba81fc5f6a53db58b6',
      'native_key' => 'OnCacheUpdate',
      'filename' => 'modEvent/fa2422a8bdaa5f1c67d5f74fb5e6c04e.vehicle',
    ),
    134 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '404aabbfa36fefb6af8658abca5fc766',
      'native_key' => 'OnLoadWebPageCache',
      'filename' => 'modEvent/cf895d2d90e29e7bd0137314a3bd0ff4.vehicle',
    ),
    135 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '4c3ce21527c224d2b05bc86475339ef0',
      'native_key' => 'OnBeforeSaveWebPageCache',
      'filename' => 'modEvent/6ec175dc60dd49db46ac7ca403a08ce2.vehicle',
    ),
    136 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'e7c6b31227ee1c3e985efb89648ee4e4',
      'native_key' => 'OnSiteRefresh',
      'filename' => 'modEvent/ae098b149f2c7c959234035d6cc1b014.vehicle',
    ),
    137 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'f86f9386b1529a465ae401ac481e893e',
      'native_key' => 'OnFileManagerDirCreate',
      'filename' => 'modEvent/0ff0601c4317b489b35524a74544d195.vehicle',
    ),
    138 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '2c6c2a5cced0220c6f321f20c2076dfb',
      'native_key' => 'OnFileManagerDirRemove',
      'filename' => 'modEvent/00e5fd901525ead15febf26d67bbe24d.vehicle',
    ),
    139 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'c616c09fe50537bcc4d460ddfc125df0',
      'native_key' => 'OnFileManagerDirRename',
      'filename' => 'modEvent/a2d53688764e8f67f3817c2b5273056b.vehicle',
    ),
    140 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '73fb3d38d87cc406977cff6b578ceb8d',
      'native_key' => 'OnFileManagerFileRename',
      'filename' => 'modEvent/e8dd953df80d301f2d9cd6630f52345e.vehicle',
    ),
    141 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '7201ec3a17a9a5603aeca0c0895bd2c4',
      'native_key' => 'OnFileManagerFileRemove',
      'filename' => 'modEvent/cf5c7325a3408f929a37288d8dfae761.vehicle',
    ),
    142 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'f387f8564a136e17789e6ea099d4a3f5',
      'native_key' => 'OnFileManagerFileUpdate',
      'filename' => 'modEvent/bd47d38d69e9eed0aaec1dfe4aaa2266.vehicle',
    ),
    143 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'a259399871fea5a71b65ed6f6981ebbe',
      'native_key' => 'OnFileManagerFileCreate',
      'filename' => 'modEvent/ad2b1510cc177b31d60060ea12e28659.vehicle',
    ),
    144 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'c1d86e23e08baadec92470a52791656d',
      'native_key' => 'OnFileManagerBeforeUpload',
      'filename' => 'modEvent/d246f30f7298c05b1f290299ab89e6e4.vehicle',
    ),
    145 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'd0bd549780a79e701d7132972a3016f5',
      'native_key' => 'OnFileManagerUpload',
      'filename' => 'modEvent/5cdf871234ce9d8e7e676fdf8045b169.vehicle',
    ),
    146 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '5d836c7397fb23e0a83214794e5ee5f0',
      'native_key' => 'OnFileManagerMoveObject',
      'filename' => 'modEvent/039ba0ab45c34f8b6f01344098ef0149.vehicle',
    ),
    147 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '7670d54c16db9c2d520b4db589f3f962',
      'native_key' => 'OnFileCreateFormPrerender',
      'filename' => 'modEvent/3a96080c3ea17e40e4a15c4b3d64d496.vehicle',
    ),
    148 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '9581ccbcbff4935afecb67d2eb2e1866',
      'native_key' => 'OnFileEditFormPrerender',
      'filename' => 'modEvent/9447440ef6579e5a00066be3ed0b8bed.vehicle',
    ),
    149 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '2ecb01d63707787bed88c163636d83fb',
      'native_key' => 'OnManagerPageInit',
      'filename' => 'modEvent/21285c2f4a9454f08e71d0ae6c21221a.vehicle',
    ),
    150 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '9e1f7dbbea47dab120bc21003a501511',
      'native_key' => 'OnManagerPageBeforeRender',
      'filename' => 'modEvent/a88d5a5f89e8a4c383dd86bd26b839be.vehicle',
    ),
    151 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'f04c8df400739f014fdd5b9a1c087ae0',
      'native_key' => 'OnManagerPageAfterRender',
      'filename' => 'modEvent/7983d2f44fcace23c3f5e9707f2347d6.vehicle',
    ),
    152 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '6fe3a93baec492624280c35197cd56eb',
      'native_key' => 'OnWebPageInit',
      'filename' => 'modEvent/179a1ed400c19bc1feeb66d447729ea5.vehicle',
    ),
    153 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '67f4387829aa07fe4a9f2c5a868f66e5',
      'native_key' => 'OnLoadWebDocument',
      'filename' => 'modEvent/8f07ed0fda5cb74c960521b6304997ef.vehicle',
    ),
    154 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '8a6744aed779b097a935b8136c1127ba',
      'native_key' => 'OnParseDocument',
      'filename' => 'modEvent/27f1b3a8154e924088ca9ff63e086b1b.vehicle',
    ),
    155 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '8db47b66a9571984c66d33d39f1b1c71',
      'native_key' => 'OnWebPageComplete',
      'filename' => 'modEvent/cf57fd2eaeeb04c13f7e90dce1038893.vehicle',
    ),
    156 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '479ca73eefc288bb1cae50e32d4edc2f',
      'native_key' => 'OnBeforeManagerPageInit',
      'filename' => 'modEvent/5e0ca649842a3ca65b1f3ef90e9abf47.vehicle',
    ),
    157 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'f4f35f07835739a7c4ad62ee64d671e4',
      'native_key' => 'OnPageNotFound',
      'filename' => 'modEvent/19ae45ec5e3e94d7d3310646b60369f0.vehicle',
    ),
    158 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '2ec66f6dfb60e3af8817f96d28d85f63',
      'native_key' => 'OnHandleRequest',
      'filename' => 'modEvent/d74241a1fa799cface8c5ec506847007.vehicle',
    ),
    159 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '4aed05d40d94dbfdc65ecc399d955cb1',
      'native_key' => 'OnMODXInit',
      'filename' => 'modEvent/ae77abb866135e4ec51b48f964704ed7.vehicle',
    ),
    160 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '550623e82b5fc3210e50ac1b6ec687bd',
      'native_key' => 'OnElementNotFound',
      'filename' => 'modEvent/a34c848963d07c931c5d42d485a80013.vehicle',
    ),
    161 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'f8bce463d274a3e75c771b2596c4c49e',
      'native_key' => 'OnSiteSettingsRender',
      'filename' => 'modEvent/6acc97b09d83a414928b981fcfbff239.vehicle',
    ),
    162 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'cf6acd9ea817285cef1beccba88232f6',
      'native_key' => 'OnInitCulture',
      'filename' => 'modEvent/2c6efd0e5ef4566628205a222e7f3a6b.vehicle',
    ),
    163 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '8b9bda2b2a3463388f0bd9bbea8b0acf',
      'native_key' => 'OnCategorySave',
      'filename' => 'modEvent/88e6773136b7bd82390e9d3233682fc0.vehicle',
    ),
    164 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'b411dfefa9ca7fd3cae8575ef625cf25',
      'native_key' => 'OnCategoryBeforeSave',
      'filename' => 'modEvent/d3fcfe351a04455888eebedafcfd4e50.vehicle',
    ),
    165 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '1697e0cf06a93d995036ebb466f99118',
      'native_key' => 'OnCategoryRemove',
      'filename' => 'modEvent/50b99a0a4d43f8118ae700b6fa788a39.vehicle',
    ),
    166 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'ab6f5289308e454648f78830e10e2769',
      'native_key' => 'OnCategoryBeforeRemove',
      'filename' => 'modEvent/251405bd22c0c71365cedfa2dc7b8bb9.vehicle',
    ),
    167 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'a34c66bd3fe3b66b429756f488cab1b3',
      'native_key' => 'OnChunkSave',
      'filename' => 'modEvent/c7bee5d247693b5c734cb946b7c82a9c.vehicle',
    ),
    168 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '3c6a69c83b0284e576885d2c8ab0d07f',
      'native_key' => 'OnChunkBeforeSave',
      'filename' => 'modEvent/1c819eba0c6bdfc95f1dbb7f73f7da37.vehicle',
    ),
    169 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '43aa68228efad6a6c08cb682ae53e23a',
      'native_key' => 'OnChunkRemove',
      'filename' => 'modEvent/2cc85235b669129ba6bc7134d105664c.vehicle',
    ),
    170 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '584a2f789b1476d102e0b8595e63931e',
      'native_key' => 'OnChunkBeforeRemove',
      'filename' => 'modEvent/13306f76157f606094d05a55c0cc8484.vehicle',
    ),
    171 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '3631212c76297b1dd391f9f4e169cb93',
      'native_key' => 'OnChunkFormPrerender',
      'filename' => 'modEvent/2612372978be3dcb516b586881c8cb00.vehicle',
    ),
    172 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'd04345ed6777fa31f7dabb9854e0657f',
      'native_key' => 'OnChunkFormRender',
      'filename' => 'modEvent/fd02242becd55b8ce3637b2eeee8921e.vehicle',
    ),
    173 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'ab805a89a57140f41ec0bd146df0ceff',
      'native_key' => 'OnBeforeChunkFormSave',
      'filename' => 'modEvent/af8a4add33b70f645d1c695a402b5d6d.vehicle',
    ),
    174 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '73071f2e559c79571630553e9b3cc849',
      'native_key' => 'OnChunkFormSave',
      'filename' => 'modEvent/260310b3bb007e299d72945eafbdaf8c.vehicle',
    ),
    175 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '84f5b8854ca188214a23ea33a7f1f84a',
      'native_key' => 'OnBeforeChunkFormDelete',
      'filename' => 'modEvent/4fc9fdd1440971561e78c33ce0251cc8.vehicle',
    ),
    176 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '3ccc7089e70d694371ea93a70a196884',
      'native_key' => 'OnChunkFormDelete',
      'filename' => 'modEvent/90452624fa8c5d31c7ca9100140ac6f2.vehicle',
    ),
    177 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'b45addf50dc30b9f69aaa91448d90829',
      'native_key' => 'OnContextSave',
      'filename' => 'modEvent/c4d26ec015c44f12d2d441bffa9845de.vehicle',
    ),
    178 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'ffff635156dbc9f2ea73ef2f8caabe88',
      'native_key' => 'OnContextBeforeSave',
      'filename' => 'modEvent/3e73c706807019b58e4aae5bb34d72d9.vehicle',
    ),
    179 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'fdb37f70f12acf84e780bec9ef53050f',
      'native_key' => 'OnContextRemove',
      'filename' => 'modEvent/78a8b1a5af49c247a2da38de5d4332f7.vehicle',
    ),
    180 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '631963479f9db24e40bf3a1610b97b9f',
      'native_key' => 'OnContextBeforeRemove',
      'filename' => 'modEvent/82a0135aef19516dbcddbe30958ddd77.vehicle',
    ),
    181 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'ad190b42c9a780acf089668ce5c22a47',
      'native_key' => 'OnContextFormPrerender',
      'filename' => 'modEvent/269bdfb69cfa05c9a1b2e0915e9b3df3.vehicle',
    ),
    182 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '19ea025a336a7e10872d4ce372aaf5b7',
      'native_key' => 'OnContextFormRender',
      'filename' => 'modEvent/8af0b6ac3ee041acab1f3adf9e53b342.vehicle',
    ),
    183 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '9fc8c4d47013378cf3167da7132535de',
      'native_key' => 'OnPluginSave',
      'filename' => 'modEvent/164a4ce14dd2433db90fb2ec360faa62.vehicle',
    ),
    184 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '6bebe72af2f717a2b2e6851fb6a86a57',
      'native_key' => 'OnPluginBeforeSave',
      'filename' => 'modEvent/e0f58d97f945cf25a074600b6fc24461.vehicle',
    ),
    185 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '2fcf185c8a0ce67b8bbcf21feac9b7fc',
      'native_key' => 'OnPluginRemove',
      'filename' => 'modEvent/52702198876527ced8319320cc975c51.vehicle',
    ),
    186 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '2a68f8784e1b69ecb7d6b154a43a2271',
      'native_key' => 'OnPluginBeforeRemove',
      'filename' => 'modEvent/a83663209ba0b1ff7297a1b8b7ff0a36.vehicle',
    ),
    187 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'd35805c293656618959a9d2e9c159f03',
      'native_key' => 'OnPluginFormPrerender',
      'filename' => 'modEvent/c5b70b2ed5182563ccfdee29d1ad48ae.vehicle',
    ),
    188 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '8d3471c577d5239de8ca968696e6c30a',
      'native_key' => 'OnPluginFormRender',
      'filename' => 'modEvent/c18c4025a7182de5eab69a8f3ab04291.vehicle',
    ),
    189 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '575cb4e070020be5f7bb7147e0114fa9',
      'native_key' => 'OnBeforePluginFormSave',
      'filename' => 'modEvent/31d685baa5f496a3091913feae7c4ce9.vehicle',
    ),
    190 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '8ea86524c98f14e7ea4f3073b25f10f7',
      'native_key' => 'OnPluginFormSave',
      'filename' => 'modEvent/2883ef15da226854bee9bdaff7a024fe.vehicle',
    ),
    191 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'bfbe6143bb1ce90fb65cd37108614699',
      'native_key' => 'OnBeforePluginFormDelete',
      'filename' => 'modEvent/0ac790bf3d24bf9c2817e6f9bd96fa62.vehicle',
    ),
    192 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '39c626b1e8307305b69918efd55040fe',
      'native_key' => 'OnPluginFormDelete',
      'filename' => 'modEvent/85b82f7d77eac130596382cd9505dccc.vehicle',
    ),
    193 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '47d981189f40979ccf393e728a9d34ed',
      'native_key' => 'OnPropertySetSave',
      'filename' => 'modEvent/6647e966784c0c38a2077473378fe0f9.vehicle',
    ),
    194 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'c8caea875e2d770458240af6405545c5',
      'native_key' => 'OnPropertySetBeforeSave',
      'filename' => 'modEvent/695ec0d049575cde4821358cddc0741a.vehicle',
    ),
    195 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '28e64d4c685ace92d6210a2141c18e98',
      'native_key' => 'OnPropertySetRemove',
      'filename' => 'modEvent/cd3fb2881177cad82926cb7b06b1d0f1.vehicle',
    ),
    196 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'e3bc60fa1c2c39413cc3372b45bbb8c2',
      'native_key' => 'OnPropertySetBeforeRemove',
      'filename' => 'modEvent/a50d97f8f3345dd701c11d2b3b5262d6.vehicle',
    ),
    197 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '376f57df5dc85d6bf278d8a666ab782a',
      'native_key' => 'OnMediaSourceBeforeFormDelete',
      'filename' => 'modEvent/25b159f1f937e792fc04249bb6e9cfea.vehicle',
    ),
    198 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '7d306fe330ffeaf2db31a7adb4acdf2e',
      'native_key' => 'OnMediaSourceBeforeFormSave',
      'filename' => 'modEvent/bd3156b01548ffb6b517bc44b78912a7.vehicle',
    ),
    199 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '4c3b1ba6ddec0a64b25afab9be8cd74c',
      'native_key' => 'OnMediaSourceGetProperties',
      'filename' => 'modEvent/a4d0ec7f4e0b2cbd96a7dde5c41c7dce.vehicle',
    ),
    200 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'c46a35d55bd508454c9d868c4f2a235f',
      'native_key' => 'OnMediaSourceFormDelete',
      'filename' => 'modEvent/f05a1c3c44d70b88eefae7bd5ad05cac.vehicle',
    ),
    201 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'a8d6d4250303816bf1bd1c9b768f67d7',
      'native_key' => 'OnMediaSourceFormSave',
      'filename' => 'modEvent/254cebb6fa2b13c6ef7a73661e04878e.vehicle',
    ),
    202 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '39a415982f781169537cd5bd090f314f',
      'native_key' => 'OnMediaSourceDuplicate',
      'filename' => 'modEvent/30466a6c141ecf09790d87cbcc6f903c.vehicle',
    ),
    203 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'be1883db0bbe4009120a8be1d2c73a55',
      'native_key' => 'access_category_enabled',
      'filename' => 'modSystemSetting/935044ac9398f5d9aa3fb83d77f9628c.vehicle',
    ),
    204 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '8e4263d94c3109ced16cf0a8030fa516',
      'native_key' => 'access_context_enabled',
      'filename' => 'modSystemSetting/e0dd8fe6b4e4adfad1ce8be2f472562a.vehicle',
    ),
    205 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'b4387711b1a10753f8a49b0a7d1c303f',
      'native_key' => 'access_resource_group_enabled',
      'filename' => 'modSystemSetting/9f6d4b198a86e7d29196dc8d8a4e4f11.vehicle',
    ),
    206 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd9d9c59cede7f66324c87f3588080f28',
      'native_key' => 'allow_forward_across_contexts',
      'filename' => 'modSystemSetting/8b2d7055f894fb61eb5e96aa1cf30f3a.vehicle',
    ),
    207 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '2845efe0a2873badf8c7c03ba539203f',
      'native_key' => 'allow_manager_login_forgot_password',
      'filename' => 'modSystemSetting/9f5db8101d04288dae825f4c2afb93a5.vehicle',
    ),
    208 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '85e24a6f84f5863d9f38985730dcf363',
      'native_key' => 'allow_multiple_emails',
      'filename' => 'modSystemSetting/1434f308eb4b42a2f75dce9528164f1e.vehicle',
    ),
    209 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '68b648dd27f9209e20802ec6520ed6cb',
      'native_key' => 'allow_tags_in_post',
      'filename' => 'modSystemSetting/26b67915775edb00baf009b4d05b01f4.vehicle',
    ),
    210 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '6f94bbf15ca58a6de5f70d0e959d7724',
      'native_key' => 'archive_with',
      'filename' => 'modSystemSetting/fec7e86011a9746244a31408de17137a.vehicle',
    ),
    211 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'eeb3141480e495108b50f9d8caed79b1',
      'native_key' => 'auto_menuindex',
      'filename' => 'modSystemSetting/bb5381860430ea4de267ab9b175f11b2.vehicle',
    ),
    212 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '106a563d6fe028b86540294a7b800bdc',
      'native_key' => 'auto_check_pkg_updates',
      'filename' => 'modSystemSetting/c6b453afa995280251f8821b5f47adc3.vehicle',
    ),
    213 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c2f496b43d9aada2c4e0341827a3263c',
      'native_key' => 'auto_check_pkg_updates_cache_expire',
      'filename' => 'modSystemSetting/0c742cae25cd91833a6fcde21c29a20e.vehicle',
    ),
    214 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '7fbf6bd6d7f9d77f6d7bdbc65f9a59d8',
      'native_key' => 'automatic_alias',
      'filename' => 'modSystemSetting/717a43361aa793033ea64e392ab8d9ad.vehicle',
    ),
    215 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '35b34f59b8004c58cad11a7f8eb0fe2d',
      'native_key' => 'base_help_url',
      'filename' => 'modSystemSetting/818f6f952da5f5b4ec2e2cb5d69f7b6e.vehicle',
    ),
    216 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '44d5b1b19421f081ca7d88c1bcf7f690',
      'native_key' => 'blocked_minutes',
      'filename' => 'modSystemSetting/274897e73739c097eff75e5155936e27.vehicle',
    ),
    217 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '8a684094ffac3d9622507ea41e158579',
      'native_key' => 'cache_action_map',
      'filename' => 'modSystemSetting/88794336c311cfd583bd4df44fc8a662.vehicle',
    ),
    218 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'cbc68cc13e9808dfdeb7675e44097c94',
      'native_key' => 'cache_alias_map',
      'filename' => 'modSystemSetting/8525add64fa5bd2944f641d137c17a50.vehicle',
    ),
    219 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '8c8bcf88280971a2623f11a14f9db579',
      'native_key' => 'cache_context_settings',
      'filename' => 'modSystemSetting/98e475b4c39d1d5f41a32d0749974bcc.vehicle',
    ),
    220 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '68bd6b8dd89507e00f0e47007157717a',
      'native_key' => 'cache_db',
      'filename' => 'modSystemSetting/dbd11df9f04005448af3bd4392da68fe.vehicle',
    ),
    221 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '036a1b30f43fc61f4bb9710a0ec8b724',
      'native_key' => 'cache_db_expires',
      'filename' => 'modSystemSetting/afcc40da036f212daa26ece5c348d17d.vehicle',
    ),
    222 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '55770d6ee91548d540a3bd54b554e5ea',
      'native_key' => 'cache_db_session',
      'filename' => 'modSystemSetting/0075b6246bedfcb15d4b33045261f07b.vehicle',
    ),
    223 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e4436072d094b65a3a236e6e1c864476',
      'native_key' => 'cache_db_session_lifetime',
      'filename' => 'modSystemSetting/de1233ebd6b1b8db543fb1e42b52d6d5.vehicle',
    ),
    224 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c630c9d944ea3713c34ba41decd06c98',
      'native_key' => 'cache_default',
      'filename' => 'modSystemSetting/fe5ecd0c04dea78d6511bad7e866cb67.vehicle',
    ),
    225 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c9d7dedf1393832408f8a30259ebfd9d',
      'native_key' => 'cache_disabled',
      'filename' => 'modSystemSetting/585cb0f3d8e3898107c3d27596b93cc0.vehicle',
    ),
    226 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e56b957dcefbf7937e8eae50a4b2fb56',
      'native_key' => 'cache_expires',
      'filename' => 'modSystemSetting/18c7eae8b596ecc80422b0aba628f47d.vehicle',
    ),
    227 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c862baeac564f47023b01140dfa79f97',
      'native_key' => 'cache_format',
      'filename' => 'modSystemSetting/8de511bfb8d78d3f83b80a915e77393a.vehicle',
    ),
    228 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ba917b54c629f15a9152692ba4deae49',
      'native_key' => 'cache_handler',
      'filename' => 'modSystemSetting/c9a266240b5e9b04109ed50de74f9070.vehicle',
    ),
    229 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'b930f0914c507a0579fb42c7916651d0',
      'native_key' => 'cache_lang_js',
      'filename' => 'modSystemSetting/d334c2d4897c305a29cf2de42ecaf10c.vehicle',
    ),
    230 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '067fd88d1a6dc6729939fec1edada390',
      'native_key' => 'cache_lexicon_topics',
      'filename' => 'modSystemSetting/0f36ff83d04cac231da567c11d3ece2c.vehicle',
    ),
    231 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '0bf995d17c88f89c9b2cdb500fba9268',
      'native_key' => 'cache_noncore_lexicon_topics',
      'filename' => 'modSystemSetting/53f2dcf2b9dcdbe6e907062f12e9bca5.vehicle',
    ),
    232 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '5773215193282c1559aea5e8fca46f6a',
      'native_key' => 'cache_resource',
      'filename' => 'modSystemSetting/9d26aabd39fcf036f880ecb9477c4e0c.vehicle',
    ),
    233 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'fc443657b1989368fc883f9b0e0bb210',
      'native_key' => 'cache_resource_expires',
      'filename' => 'modSystemSetting/02508a133cf595d5d47203e106231b05.vehicle',
    ),
    234 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e7e4a5a2401ecc282740dcb56c8f8d26',
      'native_key' => 'cache_scripts',
      'filename' => 'modSystemSetting/6dca869efd82662fc46c0d236b82ff65.vehicle',
    ),
    235 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'febbec58161727f6d460c6008e5874b2',
      'native_key' => 'cache_system_settings',
      'filename' => 'modSystemSetting/8c3f5ecfa4a6bee18f043050d0dc9132.vehicle',
    ),
    236 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '75e653f52c805524f35f0f1d75cfe7c2',
      'native_key' => 'clear_cache_refresh_trees',
      'filename' => 'modSystemSetting/ed960e83bdb42c2b6f2e3e9843c3c27c.vehicle',
    ),
    237 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '29f804e92a7ef2ecd9921775cf0e009c',
      'native_key' => 'compress_css',
      'filename' => 'modSystemSetting/653159b94be55575dce6aefdcb569bfd.vehicle',
    ),
    238 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a854e3bc560c36cf641d559123dfd171',
      'native_key' => 'compress_js',
      'filename' => 'modSystemSetting/db559fc925e8672eb741ea17bbe8deae.vehicle',
    ),
    239 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '2b596cbb74a49bd8ad0a619949cee3e3',
      'native_key' => 'compress_js_max_files',
      'filename' => 'modSystemSetting/852456b5f8c5cf3837ef3b3581dc8b97.vehicle',
    ),
    240 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '8b3ee07ae9072798444f90d1d3d6a6f9',
      'native_key' => 'confirm_navigation',
      'filename' => 'modSystemSetting/cd2252473aa32b21e90b705125f6b499.vehicle',
    ),
    241 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '34e7e5e5ab36465aebf6b7d035c680be',
      'native_key' => 'container_suffix',
      'filename' => 'modSystemSetting/323109024b69a0c95fea769efe68a224.vehicle',
    ),
    242 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'da55b5efad7264cbf8909b2e5861ce1f',
      'native_key' => 'context_tree_sort',
      'filename' => 'modSystemSetting/9fc4ad1197b8261a1342130cc16a3edb.vehicle',
    ),
    243 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c2986113a852e4ed84477cc75c7800ab',
      'native_key' => 'context_tree_sortby',
      'filename' => 'modSystemSetting/b509c045bb7fcbb08304a399af7a36e5.vehicle',
    ),
    244 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '3a35652cd2a2319ceeb104f9a16b315a',
      'native_key' => 'context_tree_sortdir',
      'filename' => 'modSystemSetting/a11da7e559e2725178e76ef5e58dacb8.vehicle',
    ),
    245 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '9907cd351955aeecf793be0fd992feaf',
      'native_key' => 'cultureKey',
      'filename' => 'modSystemSetting/3e9105b8afb7e950ecea6b2a5af90567.vehicle',
    ),
    246 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'b8e28f58a797627b1482e6b590156265',
      'native_key' => 'date_timezone',
      'filename' => 'modSystemSetting/aa63fe1c5cfffc31f140702e7a8d801c.vehicle',
    ),
    247 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '776d5cde58dae5e99dd3eaa177086bb8',
      'native_key' => 'debug',
      'filename' => 'modSystemSetting/903ed85179c2ef43ff9f2f8e786b909e.vehicle',
    ),
    248 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '9cc29703b7ed503fa21bff749229f42b',
      'native_key' => 'default_duplicate_publish_option',
      'filename' => 'modSystemSetting/141b249a8c366fa23a918947ab4d9749.vehicle',
    ),
    249 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '585c7b99c3cf831222e2880ee7dcd9f7',
      'native_key' => 'default_media_source',
      'filename' => 'modSystemSetting/e7c0491a7da41918fc06e8b4134452b9.vehicle',
    ),
    250 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '207e91a55f61b89d01f08eda58ae7230',
      'native_key' => 'default_per_page',
      'filename' => 'modSystemSetting/8c4d3cf4b6d6be3559f2ca2eae1e5e72.vehicle',
    ),
    251 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '648c7ed4f4a73fc880009aa309560c36',
      'native_key' => 'default_context',
      'filename' => 'modSystemSetting/2aa96fbdb426dd04778bdc41231c599c.vehicle',
    ),
    252 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'bbb385c0db13723c44703a685878cf68',
      'native_key' => 'default_template',
      'filename' => 'modSystemSetting/3c84c4e9a57cb1bb566dd920032a9315.vehicle',
    ),
    253 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '81ba3dd96f6c539df6fb1c29e6705df4',
      'native_key' => 'default_content_type',
      'filename' => 'modSystemSetting/ef535b30ae57be15469f60aa399a884c.vehicle',
    ),
    254 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'acb2d724e2dbf37a69abdc861e510479',
      'native_key' => 'editor_css_path',
      'filename' => 'modSystemSetting/5311ad2393e185a3fd1d632a10cf119b.vehicle',
    ),
    255 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '93b9e9b8280054cd888adbe8d283ea50',
      'native_key' => 'editor_css_selectors',
      'filename' => 'modSystemSetting/fc7e86e02a2df4d6e77aedcf314d744b.vehicle',
    ),
    256 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '7ced720751ff3124a5db29e154c2b133',
      'native_key' => 'emailsender',
      'filename' => 'modSystemSetting/2aef0ddd798ef0c18b753b9076128d09.vehicle',
    ),
    257 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e733365a246ac706bc68ccccc8b4fb41',
      'native_key' => 'emailsubject',
      'filename' => 'modSystemSetting/0f9a16e45e747a7c6ea471bf77623e3a.vehicle',
    ),
    258 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '1ab5c2971cf03e1c2b2aac8d5d88a20a',
      'native_key' => 'enable_dragdrop',
      'filename' => 'modSystemSetting/507b3b4a1736fb36bc1f5217ef57a52e.vehicle',
    ),
    259 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '8a1f1a848e7f081c55483bae11857f3b',
      'native_key' => 'error_page',
      'filename' => 'modSystemSetting/f808f9607b6c42a1956007722da2e4c8.vehicle',
    ),
    260 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '6b75d1c57ba99025c130197fc71d0388',
      'native_key' => 'failed_login_attempts',
      'filename' => 'modSystemSetting/ff01fa29aa5f76e9af47eb278d40fe14.vehicle',
    ),
    261 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'daef5369db36305e5440c551b97c6cd5',
      'native_key' => 'fe_editor_lang',
      'filename' => 'modSystemSetting/510bd282f3aaaf5a66299ab77a4f0f12.vehicle',
    ),
    262 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '47d3b32b82b44be636b72a5ed6a2bf0e',
      'native_key' => 'feed_modx_news',
      'filename' => 'modSystemSetting/66b5af058f49cecbab3f7ff18ec24490.vehicle',
    ),
    263 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '77607b7e380bd33e3f5ec066f7017410',
      'native_key' => 'feed_modx_news_enabled',
      'filename' => 'modSystemSetting/6f9260286f9fc04debf96151dd499f36.vehicle',
    ),
    264 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd5d07bcf7dfd1e237b8c6bf7db389de6',
      'native_key' => 'feed_modx_security',
      'filename' => 'modSystemSetting/6b2828768f19e15a23ac9d798ce85ee6.vehicle',
    ),
    265 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '73dc5dd8061c76c045be346774781e49',
      'native_key' => 'feed_modx_security_enabled',
      'filename' => 'modSystemSetting/fa46ffbc4a52994df5ac0d1edc5dbc03.vehicle',
    ),
    266 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '0898fe8d30240e81db3c20ae4509cddb',
      'native_key' => 'filemanager_path',
      'filename' => 'modSystemSetting/b0c6dd326b5b7443a1c59b0e1cb8fb0e.vehicle',
    ),
    267 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '11cb7ca5ce18c8154c74b5584dac0a84',
      'native_key' => 'filemanager_path_relative',
      'filename' => 'modSystemSetting/d519042cced20782de99e7523f1ce3e2.vehicle',
    ),
    268 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '9ec5445a60040d09cbf8f198e0627fb5',
      'native_key' => 'filemanager_url',
      'filename' => 'modSystemSetting/fbdd4860bfe3d97c425654b2363e10b2.vehicle',
    ),
    269 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'fc1e8c928de3e869acb7a8f48e436b9a',
      'native_key' => 'filemanager_url_relative',
      'filename' => 'modSystemSetting/a959f5f6297360209424fdb90db0c216.vehicle',
    ),
    270 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '0aa101c81f4900ca436aa1b6dc96e506',
      'native_key' => 'forgot_login_email',
      'filename' => 'modSystemSetting/f37b70c2e79b9aa772f4d66b54aaab3d.vehicle',
    ),
    271 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '91db6898f7870c84decdd45897c557e3',
      'native_key' => 'form_customization_use_all_groups',
      'filename' => 'modSystemSetting/96db98a7e5754a345d7da95cb9191c99.vehicle',
    ),
    272 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e5088f5529c47a936dba17ab2dd91c19',
      'native_key' => 'forward_merge_excludes',
      'filename' => 'modSystemSetting/a7c2bcc5c197c7839572f43d41886c2c.vehicle',
    ),
    273 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c38063211dacb75259679ee9b280a151',
      'native_key' => 'friendly_alias_lowercase_only',
      'filename' => 'modSystemSetting/7b7fe5aba58411da70b35e437d405c8d.vehicle',
    ),
    274 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ba810da2304c440f62c480710239aec6',
      'native_key' => 'friendly_alias_max_length',
      'filename' => 'modSystemSetting/1d4119f173c7feed6f1d5fc902e74462.vehicle',
    ),
    275 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '9e62151f560e2dea008d535e7021f45c',
      'native_key' => 'friendly_alias_realtime',
      'filename' => 'modSystemSetting/94ecaaecf16e36d97a3a97ffd08c6a1a.vehicle',
    ),
    276 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '1f1203bb6948387048f958f78cf3e3d4',
      'native_key' => 'friendly_alias_restrict_chars',
      'filename' => 'modSystemSetting/5a78ad4857f62001d265e3bb6b6f1a96.vehicle',
    ),
    277 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd343b88a418f6e318dbcce81b6a08376',
      'native_key' => 'friendly_alias_restrict_chars_pattern',
      'filename' => 'modSystemSetting/e614e4d730c37a715f8144a11a19097a.vehicle',
    ),
    278 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '7d03eca9a8293612cbb7b8f94cd8834e',
      'native_key' => 'friendly_alias_strip_element_tags',
      'filename' => 'modSystemSetting/cb858bedf1366b6b456fee2b7570a758.vehicle',
    ),
    279 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd4b482d3717121a45077a16560c5d1d4',
      'native_key' => 'friendly_alias_translit',
      'filename' => 'modSystemSetting/ca84d089be9c512f3d2f4a4df1ab597a.vehicle',
    ),
    280 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '08927c30918225b5e6c6748b17019c24',
      'native_key' => 'friendly_alias_translit_class',
      'filename' => 'modSystemSetting/60c6c64434695084d4ca55400df1ac7a.vehicle',
    ),
    281 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '2bdb5ab8a3e7464b8091fbf2d607b78b',
      'native_key' => 'friendly_alias_translit_class_path',
      'filename' => 'modSystemSetting/9481fcb88a3261175bf81f73a984f2f2.vehicle',
    ),
    282 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '2dd0def96e7a03c2da09f3cf751b6fbc',
      'native_key' => 'friendly_alias_trim_chars',
      'filename' => 'modSystemSetting/a0e9403fece87015e09038586d50d4a5.vehicle',
    ),
    283 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '528fbf07abe98075060abdc1d4f5922f',
      'native_key' => 'friendly_alias_word_delimiter',
      'filename' => 'modSystemSetting/412eec5a6ae987e3ddc6df79820c5cb9.vehicle',
    ),
    284 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '7d1e11dbe7f44b9fa330e330a184ff27',
      'native_key' => 'friendly_alias_word_delimiters',
      'filename' => 'modSystemSetting/8280078fa80ff0efa18e3d8b55f66225.vehicle',
    ),
    285 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '858c669943de17a87ffeac552fe82196',
      'native_key' => 'friendly_urls',
      'filename' => 'modSystemSetting/3c74e3a81127a2741697e57c0d7a80c3.vehicle',
    ),
    286 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'b7fb23020d436010591f9e18da0bd5b6',
      'native_key' => 'friendly_urls_strict',
      'filename' => 'modSystemSetting/b25b64d61a366537f14db198f0efd90b.vehicle',
    ),
    287 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '0442ab238cc07a1f31c8da1503b22767',
      'native_key' => 'use_frozen_parent_uris',
      'filename' => 'modSystemSetting/8c4dfa79f28e64e0af00ec4e1f4c4e12.vehicle',
    ),
    288 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '5c1406cd98dcbd8f4690339bf9ebb21d',
      'native_key' => 'global_duplicate_uri_check',
      'filename' => 'modSystemSetting/4ef63a115e3414934e7b93c0a9e46672.vehicle',
    ),
    289 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '6e2df88f91f07d6c6bf468d8123cbd46',
      'native_key' => 'hidemenu_default',
      'filename' => 'modSystemSetting/307f964704bebfcae1056d6a3148a467.vehicle',
    ),
    290 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '536644f56829b48c23407bda6b821460',
      'native_key' => 'inline_help',
      'filename' => 'modSystemSetting/5ec7d2ae46f2cd4a91dc50b0f2b7107b.vehicle',
    ),
    291 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '270ffa2d35a3a39fb199204b2cd55246',
      'native_key' => 'locale',
      'filename' => 'modSystemSetting/5fc36efbdefc28970f8665c13e62e7d0.vehicle',
    ),
    292 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '909c8f7e39bf24a2e7f6849a9728573c',
      'native_key' => 'log_level',
      'filename' => 'modSystemSetting/2264e7352eb4bcba848a194d4e26f529.vehicle',
    ),
    293 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f9fe61764134d7366898160e5987eec0',
      'native_key' => 'log_target',
      'filename' => 'modSystemSetting/e7f57d70e55f02561537d498870b71c8.vehicle',
    ),
    294 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '18fa18fa622aa152161b7eb2da6c725b',
      'native_key' => 'link_tag_scheme',
      'filename' => 'modSystemSetting/fb7f7a3b30f1621037585ab0b9b50e14.vehicle',
    ),
    295 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e1f79d3583710935b2cea00e000ba157',
      'native_key' => 'lock_ttl',
      'filename' => 'modSystemSetting/24156d1d601bd701ca0ec2317d67683c.vehicle',
    ),
    296 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f0a889ff101e1db527af8573a58364b2',
      'native_key' => 'mail_charset',
      'filename' => 'modSystemSetting/b235965bc7d85af318892e6ed5ac4236.vehicle',
    ),
    297 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c616e8ce1bb509c10be4593c41a33474',
      'native_key' => 'mail_encoding',
      'filename' => 'modSystemSetting/1155a871a063d6da02315642c8a815ab.vehicle',
    ),
    298 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '228c0599a191c67873047a541af7a1f2',
      'native_key' => 'mail_use_smtp',
      'filename' => 'modSystemSetting/ed5d13a6f0ae6f85f0aa382903ffbdd4.vehicle',
    ),
    299 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e4092a4d34516132b36c3046e93900cb',
      'native_key' => 'mail_smtp_auth',
      'filename' => 'modSystemSetting/7c70c1200224964c5e557030fbf62a42.vehicle',
    ),
    300 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '72476c072c817a54108f6779cb969e7b',
      'native_key' => 'mail_smtp_helo',
      'filename' => 'modSystemSetting/58571772f0f6a3b03ac9384ddb0ec627.vehicle',
    ),
    301 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '0b52412600ae5080a9f0b1b737760e6c',
      'native_key' => 'mail_smtp_hosts',
      'filename' => 'modSystemSetting/b184d5c25bc9f995363d66fc3e12a129.vehicle',
    ),
    302 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '086476b55a1197c6d697970b3835043a',
      'native_key' => 'mail_smtp_keepalive',
      'filename' => 'modSystemSetting/7f70d44f85f1e3c0c988df6b67120dfe.vehicle',
    ),
    303 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '501f9b57092aff449e610b006d57041d',
      'native_key' => 'mail_smtp_pass',
      'filename' => 'modSystemSetting/65ecf7bf83a982080d035176cb859f6e.vehicle',
    ),
    304 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '267820cf91ca157994d73226775739d7',
      'native_key' => 'mail_smtp_port',
      'filename' => 'modSystemSetting/d2dd83a0f4580ef3fdeecdf622a4cfd9.vehicle',
    ),
    305 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ff3154805a44eb4d9a73675405637540',
      'native_key' => 'mail_smtp_prefix',
      'filename' => 'modSystemSetting/d269c4ac81dfac269dfe5ce7056a568f.vehicle',
    ),
    306 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '012736bc92ba0f34d0c98dcf137170a2',
      'native_key' => 'mail_smtp_single_to',
      'filename' => 'modSystemSetting/1bf48ccf2cfdd3d06620f1ef28be3b85.vehicle',
    ),
    307 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'aadbbf07f1a6bfbd1a2c522108d34a20',
      'native_key' => 'mail_smtp_timeout',
      'filename' => 'modSystemSetting/267d33b1d96ee0cf049e360ef3bcd385.vehicle',
    ),
    308 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '50038af7e63df2ce9eda681c63e97192',
      'native_key' => 'mail_smtp_user',
      'filename' => 'modSystemSetting/11e92b17b84460ed0f6a8312582690e9.vehicle',
    ),
    309 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd845937629c8694c8c39d79ad29b49db',
      'native_key' => 'manager_date_format',
      'filename' => 'modSystemSetting/ead20fd0b29e758ae9440093cdd8ac95.vehicle',
    ),
    310 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'b9ac09a8293d978ef8d311f73566667e',
      'native_key' => 'manager_favicon_url',
      'filename' => 'modSystemSetting/e3548b4495c3f22c2be6b45efef4a5d6.vehicle',
    ),
    311 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '1499981d943c505d148a809556d20b62',
      'native_key' => 'manager_js_cache_file_locking',
      'filename' => 'modSystemSetting/b80850381301f43d9dc7f4e9310bbf8c.vehicle',
    ),
    312 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '6097ae8626ec4a7a9234aefa4039e279',
      'native_key' => 'manager_js_cache_max_age',
      'filename' => 'modSystemSetting/0669bb3e81c9360fd88f494efa81e6af.vehicle',
    ),
    313 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ce6d230f1a9fde49877ad4804e8370b4',
      'native_key' => 'manager_js_document_root',
      'filename' => 'modSystemSetting/b6f135a9a26e1e787782c43499cd1ff5.vehicle',
    ),
    314 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '13a75d36ab2f6824bc19c06ad8a27a86',
      'native_key' => 'manager_js_zlib_output_compression',
      'filename' => 'modSystemSetting/f295f99e265c8c55b0f38882351979a6.vehicle',
    ),
    315 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd9c797322cd59c3fd966aee49eeebc34',
      'native_key' => 'manager_time_format',
      'filename' => 'modSystemSetting/76cb6b4ad3c2cf6ba583ae8d48d6762a.vehicle',
    ),
    316 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '57254f0022499c3c4e4209d882e15733',
      'native_key' => 'manager_direction',
      'filename' => 'modSystemSetting/01741e5f3ac80610a33fe50e7ac2e7cb.vehicle',
    ),
    317 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '64fe4a4688070db1976e922b22109fc3',
      'native_key' => 'manager_lang_attribute',
      'filename' => 'modSystemSetting/c10d30a2da354e2afc3e043249832061.vehicle',
    ),
    318 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ac415fbef9d7a7f613057d157d942840',
      'native_key' => 'manager_language',
      'filename' => 'modSystemSetting/9eb98653afd647e7d848806cea02ebdb.vehicle',
    ),
    319 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd60c30fc7caf2091b171dd8dcbc1ae3d',
      'native_key' => 'manager_login_url_alternate',
      'filename' => 'modSystemSetting/04190026f0d0787ba0a250e4cf7d1594.vehicle',
    ),
    320 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '310e28c995142e8eb3615a7edb4c47b3',
      'native_key' => 'manager_theme',
      'filename' => 'modSystemSetting/9a594b63ba1606668c44d73c6b7f9657.vehicle',
    ),
    321 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '8ece973c300bab645c42a18ca868e9fa',
      'native_key' => 'manager_week_start',
      'filename' => 'modSystemSetting/952d430fdc29ee1134a2aeb48f8cfb3a.vehicle',
    ),
    322 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a7c59885fc8905d311e27cdf3a418176',
      'native_key' => 'modx_browser_tree_hide_files',
      'filename' => 'modSystemSetting/752c4eedb4a5aae0f6cb40497793dbad.vehicle',
    ),
    323 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '36a7d64d886126734fd04a38642d9d25',
      'native_key' => 'modx_browser_tree_hide_tooltips',
      'filename' => 'modSystemSetting/673538498926736515aaece4f35fc420.vehicle',
    ),
    324 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '61c4be40ca57b0b56f8111a07b0bb660',
      'native_key' => 'modx_browser_default_sort',
      'filename' => 'modSystemSetting/66dd5362d245a07cbf829f7add0ec4f7.vehicle',
    ),
    325 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '9a44a14f0ea7f195ae4978dba50b9034',
      'native_key' => 'modx_browser_default_viewmode',
      'filename' => 'modSystemSetting/395e281671eac54c537994c95230ae8c.vehicle',
    ),
    326 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '8bbcc62267d120969a556856b7356d47',
      'native_key' => 'modx_charset',
      'filename' => 'modSystemSetting/07225d20b6c83119bb7546e1e4130da4.vehicle',
    ),
    327 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '4e1a267f66e1971022377f1048a25ba7',
      'native_key' => 'principal_targets',
      'filename' => 'modSystemSetting/91a2c955c7cbe9994c83c7a71c7a3bf9.vehicle',
    ),
    328 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '5908a0716aef2159665587698c4d1e1c',
      'native_key' => 'proxy_auth_type',
      'filename' => 'modSystemSetting/be141bdc1b3d1e8eea8b3a45afc0e214.vehicle',
    ),
    329 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c2a2770843704f39526ac9a011068f30',
      'native_key' => 'proxy_host',
      'filename' => 'modSystemSetting/6f2d5ac07b1d007959896a24e934bff4.vehicle',
    ),
    330 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '8bec29b656df3325f64c33b7a5824a1e',
      'native_key' => 'proxy_password',
      'filename' => 'modSystemSetting/b031e1e1bc4fec6ad44cd3152df15c32.vehicle',
    ),
    331 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f1b89b63dd98dd8eecdcb3c64f39b49c',
      'native_key' => 'proxy_port',
      'filename' => 'modSystemSetting/1561446cc485725e4b8ee3d9e72aea6a.vehicle',
    ),
    332 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '3531584240ba92c6a5783bf6a7ae208b',
      'native_key' => 'proxy_username',
      'filename' => 'modSystemSetting/2f5d4082d47a86096891482df3bb2abd.vehicle',
    ),
    333 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '1335cf42d32da18a1b25c890f076d0b6',
      'native_key' => 'password_generated_length',
      'filename' => 'modSystemSetting/092ccd4338d5e1ca94f8461febd08f9e.vehicle',
    ),
    334 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f296266f8a142081cb2f714c9714777a',
      'native_key' => 'password_min_length',
      'filename' => 'modSystemSetting/76226c1d84d6b219cb5437f99660d1f7.vehicle',
    ),
    335 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '5355eda0a931d195325374108f74deca',
      'native_key' => 'phpthumb_allow_src_above_docroot',
      'filename' => 'modSystemSetting/d547aa4d0a2ceccc932daafb676998cc.vehicle',
    ),
    336 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'b8956c100387a24dd9941c536846b4b2',
      'native_key' => 'phpthumb_cache_maxage',
      'filename' => 'modSystemSetting/97480108c2856e704a291bcc91777fd1.vehicle',
    ),
    337 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '8c0b12c0f082ccf2f3a368985daab006',
      'native_key' => 'phpthumb_cache_maxsize',
      'filename' => 'modSystemSetting/9dba810905ff93038e8fdedc6611b32c.vehicle',
    ),
    338 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e1bf1b7ca95d0adf2fc0b879a6cd519b',
      'native_key' => 'phpthumb_cache_maxfiles',
      'filename' => 'modSystemSetting/325e65904611451e2bf9bbc1a7a9bdd5.vehicle',
    ),
    339 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd16a89a15a65c1e4a2830dcac74f21e2',
      'native_key' => 'phpthumb_cache_source_enabled',
      'filename' => 'modSystemSetting/4ecb0012258ef80ed644472b00484f4a.vehicle',
    ),
    340 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '4a5d096cd3a85361de99c94617c1fb1e',
      'native_key' => 'phpthumb_document_root',
      'filename' => 'modSystemSetting/7376f3adbad22855b517a48d8c9cdfb5.vehicle',
    ),
    341 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f302fc028c2463b082039811c0ff4e80',
      'native_key' => 'phpthumb_error_bgcolor',
      'filename' => 'modSystemSetting/2d75d709d7772854be0b4809c50dffbd.vehicle',
    ),
    342 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '911bc1e592ce32b8281c1aa0b4d3fecb',
      'native_key' => 'phpthumb_error_textcolor',
      'filename' => 'modSystemSetting/ed15a92db04e1af47374feecf5751093.vehicle',
    ),
    343 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '30d41932f245dcd590425d40ae2ab360',
      'native_key' => 'phpthumb_error_fontsize',
      'filename' => 'modSystemSetting/5ecaea51392c84ea159d3563ab444ab5.vehicle',
    ),
    344 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '707d00f961980414fdc41a63d0afc524',
      'native_key' => 'phpthumb_far',
      'filename' => 'modSystemSetting/618a84de97a62e090c44516387c38720.vehicle',
    ),
    345 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'db6f7f5eee253f6b2708a2c449912424',
      'native_key' => 'phpthumb_imagemagick_path',
      'filename' => 'modSystemSetting/91d84e0d2b1f1dfe253c469d5a9614ad.vehicle',
    ),
    346 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'b9122dc83d60dc11ca668377311d9f45',
      'native_key' => 'phpthumb_nohotlink_enabled',
      'filename' => 'modSystemSetting/1dafec863568e05c39c3ee9e3b855f6d.vehicle',
    ),
    347 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '33db3f8b1d76075c123330609527d7f1',
      'native_key' => 'phpthumb_nohotlink_erase_image',
      'filename' => 'modSystemSetting/9436b8594dfe58c482b2ec41133be818.vehicle',
    ),
    348 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '0e099ad43d9756a6966b584308aa14c3',
      'native_key' => 'phpthumb_nohotlink_valid_domains',
      'filename' => 'modSystemSetting/6e44f73c0af8593f3c38fb70568a1f1d.vehicle',
    ),
    349 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ca8ac79f0bfb541d365e605571fdfb13',
      'native_key' => 'phpthumb_nohotlink_text_message',
      'filename' => 'modSystemSetting/75adab1a5e6556e4d8993fef01c95d6c.vehicle',
    ),
    350 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ac93101e4ffd4764cec2efaa2bd45b5b',
      'native_key' => 'phpthumb_nooffsitelink_enabled',
      'filename' => 'modSystemSetting/602b4a2746e7a5db5e497dc7816af0f6.vehicle',
    ),
    351 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e9be023d9a9e22a5c76ba55d515fba17',
      'native_key' => 'phpthumb_nooffsitelink_erase_image',
      'filename' => 'modSystemSetting/e7149be4dab358efb17859bd88f0e8ce.vehicle',
    ),
    352 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '32d68ef68d5eb9c94c07e38c3748c161',
      'native_key' => 'phpthumb_nooffsitelink_require_refer',
      'filename' => 'modSystemSetting/e1a6bae711e0d71f830b350f06ace033.vehicle',
    ),
    353 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e5fab040698998717413fefda9331715',
      'native_key' => 'phpthumb_nooffsitelink_text_message',
      'filename' => 'modSystemSetting/6b19ce2151f4daeb14b97d77a99e29ce.vehicle',
    ),
    354 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '173f96cc116adf46e27f260f022b3678',
      'native_key' => 'phpthumb_nooffsitelink_valid_domains',
      'filename' => 'modSystemSetting/dc07cef17443617a4c895aa85a630390.vehicle',
    ),
    355 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '0b30470fec531e8e5135a820deca146e',
      'native_key' => 'phpthumb_nooffsitelink_watermark_src',
      'filename' => 'modSystemSetting/6f75dec8f9fa3424c169440e3165279e.vehicle',
    ),
    356 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '5a88b74566dbb78bfc1272f276f241e3',
      'native_key' => 'phpthumb_zoomcrop',
      'filename' => 'modSystemSetting/030462591aa10fb21f8c98c95624ede1.vehicle',
    ),
    357 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '93b1ae801f4435404595de226d4b3ffb',
      'native_key' => 'publish_default',
      'filename' => 'modSystemSetting/5ac35bd021e4450b3abc5531fcbee913.vehicle',
    ),
    358 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '78989c6409ce13f24e474bd7ef809b0e',
      'native_key' => 'rb_base_dir',
      'filename' => 'modSystemSetting/6f25a842abb0a8f71377a19d4a3d22a9.vehicle',
    ),
    359 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e1303018ea53622c255cc67001b15fff',
      'native_key' => 'rb_base_url',
      'filename' => 'modSystemSetting/5787a72327184ea1f784dc57977384a4.vehicle',
    ),
    360 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e7fe9072f5a8132d4e09aeadbb74db88',
      'native_key' => 'request_controller',
      'filename' => 'modSystemSetting/9755a98ab8000eac6c5bae077d473b51.vehicle',
    ),
    361 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '45b914d7a36d8bebc3357bad2bac37ef',
      'native_key' => 'request_method_strict',
      'filename' => 'modSystemSetting/f3af8c7e9fbbaea9b3e753c2e69d5d22.vehicle',
    ),
    362 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '0aa0bbfb554b93516ab5c730c8b08d39',
      'native_key' => 'request_param_alias',
      'filename' => 'modSystemSetting/d8a27d816ff1bc7999ecd09ecd82d8ca.vehicle',
    ),
    363 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '53d2f901fef0330aae9a185961d92363',
      'native_key' => 'request_param_id',
      'filename' => 'modSystemSetting/801109f31c5417de8cad3482067159c5.vehicle',
    ),
    364 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '0a83ccaa83bd18dc1663d45ef3a734ad',
      'native_key' => 'resolve_hostnames',
      'filename' => 'modSystemSetting/8f1a056778686eaccefa66015e9389f9.vehicle',
    ),
    365 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd2c46c31b1dec38f341971939bcfbc83',
      'native_key' => 'resource_tree_node_name',
      'filename' => 'modSystemSetting/806419456614df9d784cceaf136104ed.vehicle',
    ),
    366 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'b224ac54ae3ebafb17458916804bdc92',
      'native_key' => 'resource_tree_node_name_fallback',
      'filename' => 'modSystemSetting/9f9cb4740eadbca6085aabe01c360387.vehicle',
    ),
    367 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '17340cc94dc94b910fa9440a1966aae9',
      'native_key' => 'resource_tree_node_tooltip',
      'filename' => 'modSystemSetting/2607e9727ad560483ab3c34fed4fcf82.vehicle',
    ),
    368 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '64d9964c0d2c023c4176b78346856837',
      'native_key' => 'richtext_default',
      'filename' => 'modSystemSetting/e9dc80c4eee434fa3b5d77c23e030e54.vehicle',
    ),
    369 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd71f6a251ea337a7f3a9ac2887e2bd54',
      'native_key' => 'search_default',
      'filename' => 'modSystemSetting/a048f9cf5b07d8b63c231d43cefea01e.vehicle',
    ),
    370 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd8c833e7026082ace0aab18a88db1d5f',
      'native_key' => 'server_offset_time',
      'filename' => 'modSystemSetting/0567f681239fad8115e004bb57ff0bc3.vehicle',
    ),
    371 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'dcd9b0d92565cfbf8a90b7004e64e72c',
      'native_key' => 'server_protocol',
      'filename' => 'modSystemSetting/7579d03b90882043bf1d531910fa6f59.vehicle',
    ),
    372 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a983bc83b2e8fc163cc50126d3bd7476',
      'native_key' => 'session_cookie_domain',
      'filename' => 'modSystemSetting/8842e5631d874cf9df73e993b61e46c5.vehicle',
    ),
    373 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '71f09c1b0930b876e77606025169c697',
      'native_key' => 'default_username',
      'filename' => 'modSystemSetting/0fff73b01a01628ec3b892d942e9c502.vehicle',
    ),
    374 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c0c1281c544b90ef583c3285a42e42d9',
      'native_key' => 'anonymous_sessions',
      'filename' => 'modSystemSetting/0649ad8f2eb199fe592821fc30a08e00.vehicle',
    ),
    375 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e53d987220492759c99a48a74e95d841',
      'native_key' => 'session_cookie_lifetime',
      'filename' => 'modSystemSetting/5093e6a9bf899fea1bd9d5124344bd66.vehicle',
    ),
    376 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '5bc73525c6e8d9ac115cb5bbd44a421c',
      'native_key' => 'session_cookie_path',
      'filename' => 'modSystemSetting/182ebd2b999da87c426348fde8909211.vehicle',
    ),
    377 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a59f971b7f167a34e6078d27bc9d6deb',
      'native_key' => 'session_cookie_secure',
      'filename' => 'modSystemSetting/8eb540e5e52ec768dcc528ef9471cddc.vehicle',
    ),
    378 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'dab07153770a350c77b30c3743fd0208',
      'native_key' => 'session_cookie_httponly',
      'filename' => 'modSystemSetting/5f19ab7225538b4467ec5f64a6cfc1e5.vehicle',
    ),
    379 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f69b7208926dadb1aa1ebcf6ef16e0f2',
      'native_key' => 'session_gc_maxlifetime',
      'filename' => 'modSystemSetting/036a2040a5c712e2fe698c3dfb37fa48.vehicle',
    ),
    380 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '39cd83ab6eea7f12985bec64793fd597',
      'native_key' => 'session_handler_class',
      'filename' => 'modSystemSetting/a95ba0f9e9f7b55f234ae51ea1ad7ec7.vehicle',
    ),
    381 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '2e523f95697f9e4f78024cb434fa0896',
      'native_key' => 'session_name',
      'filename' => 'modSystemSetting/5ce1fed47682e171f35554db22ef23e3.vehicle',
    ),
    382 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '9bfed0a19326f4a3abb2d84e4f2bd757',
      'native_key' => 'set_header',
      'filename' => 'modSystemSetting/455c40af98da06ac2a1d165832777d59.vehicle',
    ),
    383 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '9eeaba9b7222445afd0c854b70c1e4c2',
      'native_key' => 'send_poweredby_header',
      'filename' => 'modSystemSetting/a3aaccf8ba696d2287f1b6da7754e098.vehicle',
    ),
    384 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '1fa8270c7ea31bfc8f5553e30892e44f',
      'native_key' => 'show_tv_categories_header',
      'filename' => 'modSystemSetting/bdd6a6fca5f41351e2de71bb0a418f59.vehicle',
    ),
    385 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ff2d092ed359138e9992ee1599ba0b9b',
      'native_key' => 'signupemail_message',
      'filename' => 'modSystemSetting/af0b790243b7055e81a22da4fc433914.vehicle',
    ),
    386 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c1f34c0f8063872979450072b7089a9c',
      'native_key' => 'site_name',
      'filename' => 'modSystemSetting/f2471b542f2bb6b0e2bf78d9d3febbde.vehicle',
    ),
    387 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '66bb6a6da06e20341c1fa3ba9f5aebac',
      'native_key' => 'site_start',
      'filename' => 'modSystemSetting/a61c719106c63e3732849480d4bf11e0.vehicle',
    ),
    388 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c8ff7c46229e55a24bc255ca5cf5d1ae',
      'native_key' => 'site_status',
      'filename' => 'modSystemSetting/75c49e8c13656a61c95ff777fd644ac2.vehicle',
    ),
    389 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ad676ee195f10b487d8c87587d3b2cf1',
      'native_key' => 'site_unavailable_message',
      'filename' => 'modSystemSetting/c7c010498e346b5772f57e556bb9ccc8.vehicle',
    ),
    390 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '4cbe1faa5ddf69bc46098820ab2d88c8',
      'native_key' => 'site_unavailable_page',
      'filename' => 'modSystemSetting/a3d590610ddb467e9bf6a34d29371c12.vehicle',
    ),
    391 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd85bbf7e61051b800c19619415d01d93',
      'native_key' => 'strip_image_paths',
      'filename' => 'modSystemSetting/71b16d1d868481a58c5699666e24aaf2.vehicle',
    ),
    392 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '8ef0d013eb96ce0e6a4429f0200a6d33',
      'native_key' => 'symlink_merge_fields',
      'filename' => 'modSystemSetting/8d807c1024541b813097e7d34d31f7ec.vehicle',
    ),
    393 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '2e4bd1e8df0bfe9af78d80b278556020',
      'native_key' => 'syncsite_default',
      'filename' => 'modSystemSetting/2d893ead1b9bf2fd74a30c0871b40ab0.vehicle',
    ),
    394 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ac566e26d6ac60db24987ca1ae99bccc',
      'native_key' => 'topmenu_show_descriptions',
      'filename' => 'modSystemSetting/e6efd4828b4c26ad00498118412ac20d.vehicle',
    ),
    395 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '1e42249037259280d86a591e8c07eb04',
      'native_key' => 'tree_default_sort',
      'filename' => 'modSystemSetting/538a31d60b73d10f9614b57f1716ae0a.vehicle',
    ),
    396 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'b6956b873956695ea9303e3332569bb0',
      'native_key' => 'tree_root_id',
      'filename' => 'modSystemSetting/6f45695646def41220101b55bb09be14.vehicle',
    ),
    397 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '3b0f80a1342195886825849ac322a9de',
      'native_key' => 'tvs_below_content',
      'filename' => 'modSystemSetting/d2c78b4dd78cdcea3815e99eaf0746d5.vehicle',
    ),
    398 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '16899abfefa80f769bc4156f9a94fd8e',
      'native_key' => 'udperms_allowroot',
      'filename' => 'modSystemSetting/ed78710416eb1d9b1fe3798b7c840315.vehicle',
    ),
    399 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '8f6bb52124bfcd0934e0093e035fba57',
      'native_key' => 'unauthorized_page',
      'filename' => 'modSystemSetting/3e2e124c8a1e38d5474fd97dba36c1f6.vehicle',
    ),
    400 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '39908b613f2b6bcc2aa3cc1f58011fed',
      'native_key' => 'upload_files',
      'filename' => 'modSystemSetting/9a313b21edd9908c805fbdb5c3088f60.vehicle',
    ),
    401 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c860e4463bc8361c0be0ac62e3a6ea2b',
      'native_key' => 'upload_flash',
      'filename' => 'modSystemSetting/30c4be3c2eafb4bb0aa084fb37c11be5.vehicle',
    ),
    402 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '0f98796a06bacf86a714570a3005eeb1',
      'native_key' => 'upload_images',
      'filename' => 'modSystemSetting/7bb9b15b843f87ea3422ac184ef619e4.vehicle',
    ),
    403 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '850362a4e44428e7df7b451ad9921891',
      'native_key' => 'upload_maxsize',
      'filename' => 'modSystemSetting/8b87b92f40e4862d44bcd3765f5bd758.vehicle',
    ),
    404 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e5f7a1df5cd4b5eb302697adf8f2c52d',
      'native_key' => 'upload_media',
      'filename' => 'modSystemSetting/b4c5042be23a33c493b5b76bf7bf3b67.vehicle',
    ),
    405 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '55ed22755c1b9a52782c93b63ac88262',
      'native_key' => 'use_alias_path',
      'filename' => 'modSystemSetting/51a426c40248be6480973acd05a4a2b2.vehicle',
    ),
    406 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'aef2c759a433805fde3315030528deb1',
      'native_key' => 'use_browser',
      'filename' => 'modSystemSetting/c371b2c6b2674212206c651e99479716.vehicle',
    ),
    407 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '60227cd9e509aa906bc45d25c5dcf984',
      'native_key' => 'use_editor',
      'filename' => 'modSystemSetting/dd6b7c79956e1409bbf31155ba3f19fe.vehicle',
    ),
    408 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '408f20a025664f502a885aeca5d416b5',
      'native_key' => 'use_multibyte',
      'filename' => 'modSystemSetting/bbb91ac8285a147b81e4788d3d30822a.vehicle',
    ),
    409 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '03a8ae0a3eb44b52389ebd4c8cf0315b',
      'native_key' => 'use_weblink_target',
      'filename' => 'modSystemSetting/7cf5c52b7b8dca10c6bac2b9e2d33b3a.vehicle',
    ),
    410 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '786acc811e9d5872097201f5c98267a7',
      'native_key' => 'webpwdreminder_message',
      'filename' => 'modSystemSetting/c00cb5844d3addacc7186eeefca8f9b9.vehicle',
    ),
    411 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '8af09787a67b19ea36a4df04153261d4',
      'native_key' => 'websignupemail_message',
      'filename' => 'modSystemSetting/bbe6d08386af6e014b5af9d5fed32ae6.vehicle',
    ),
    412 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e5177382c3356afc624a42a1bb0e2ad5',
      'native_key' => 'welcome_screen',
      'filename' => 'modSystemSetting/7a6e68e2db36d08ac11c5e1de87bd8c0.vehicle',
    ),
    413 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '3f4a3cb0a575ef8e7cf9ccfcf37db470',
      'native_key' => 'welcome_screen_url',
      'filename' => 'modSystemSetting/66edc39b33cf0c5a77ab13389b927903.vehicle',
    ),
    414 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '877326e71b0b5a155e21c1cd75c5c23d',
      'native_key' => 'welcome_action',
      'filename' => 'modSystemSetting/c4403144a9e344e99bd7da5aa30b221f.vehicle',
    ),
    415 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '78d8680d9ce426535fa6ef1d05a387f3',
      'native_key' => 'welcome_namespace',
      'filename' => 'modSystemSetting/6841716a8d24cd84df352211a1bd7ff4.vehicle',
    ),
    416 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '2f4e88075f55e12c0d8b4d69ef469620',
      'native_key' => 'which_editor',
      'filename' => 'modSystemSetting/b1bed76ca036fb0da0491e77019f5ef4.vehicle',
    ),
    417 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '0f31322c5ed5f1f17220c72b6696ee2a',
      'native_key' => 'which_element_editor',
      'filename' => 'modSystemSetting/cd85cd7635a3ccca7474554e672d8d70.vehicle',
    ),
    418 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '383066fbd585629c09e9c37205819e59',
      'native_key' => 'xhtml_urls',
      'filename' => 'modSystemSetting/9420bba67b0a5a80b355da55d7fd9cdd.vehicle',
    ),
    419 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'bc6c4a8d856cd021b4659ce23720cccd',
      'native_key' => 'enable_gravatar',
      'filename' => 'modSystemSetting/14ff71c2c947c95b82f710aa1af4f599.vehicle',
    ),
    420 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '622694d409f93a47d475ee9c34cac181',
      'native_key' => 'mgr_tree_icon_context',
      'filename' => 'modSystemSetting/9d7afbf9a45b5ebfe7d6b21227a995d6.vehicle',
    ),
    421 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '7a30b4730b7a582a7dcdd4356877db9d',
      'native_key' => 'mgr_source_icon',
      'filename' => 'modSystemSetting/2c40de3cb8f0f3c036d30a26fcf92620.vehicle',
    ),
    422 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'fac7c91f3c99cd056a8ddb809652e882',
      'native_key' => 'main_nav_parent',
      'filename' => 'modSystemSetting/4515bc932f4449efeffd43dd1b54e351.vehicle',
    ),
    423 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '0bb766094fe45602365da1d9a2257d52',
      'native_key' => 'user_nav_parent',
      'filename' => 'modSystemSetting/76096428a3f5cda269f9cba45b17fa50.vehicle',
    ),
    424 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '748ae1aed93708a83c1bdfafb65700cf',
      'native_key' => 'auto_isfolder',
      'filename' => 'modSystemSetting/5d03d03c3ec51ca5a46ca4cb5b2c0034.vehicle',
    ),
    425 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f6a4c1ff9bad5f589d82ebd7087bfc58',
      'native_key' => 'manager_use_fullname',
      'filename' => 'modSystemSetting/557a87bee1c70846db22493032c34e82.vehicle',
    ),
    426 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '1ae11d93592b5edd6d96f2518bc70c8b',
      'native_key' => 'parser_recurse_uncacheable',
      'filename' => 'modSystemSetting/b3e38e11f820ce22c93feedda5c843d9.vehicle',
    ),
    427 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e7691805cc49c02e463c52932fd93ebb',
      'native_key' => 'preserve_menuindex',
      'filename' => 'modSystemSetting/254b324159685d500e55d200347ab9b0.vehicle',
    ),
    428 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modContextSetting',
      'guid' => '6f6a8976c692ecd9187c95a0bbe4113e',
      'native_key' => 
      array (
        0 => 'mgr',
        1 => 'allow_tags_in_post',
      ),
      'filename' => 'modContextSetting/ae0257fca9846b2e4fff616c3bbe42f6.vehicle',
    ),
    429 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modContextSetting',
      'guid' => 'd081d07d2ab4639f5fad287df0ce243f',
      'native_key' => 
      array (
        0 => 'mgr',
        1 => 'modRequest.class',
      ),
      'filename' => 'modContextSetting/4219d0b18d4877efbc675992b44cb6e8.vehicle',
    ),
    430 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modUserGroup',
      'guid' => '76fbd1586c7d373a52c26ebfcd28da65',
      'native_key' => 1,
      'filename' => 'modUserGroup/48b0897ac6d7ba772b5cd17922408738.vehicle',
    ),
    431 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modDashboard',
      'guid' => '099478f4d3df48916d69fe7558beea95',
      'native_key' => 1,
      'filename' => 'modDashboard/63564ed68661032e36691b92f0bbd040.vehicle',
    ),
    432 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMediaSource',
      'guid' => '9c302728bb69845b966cc15fafa705a5',
      'native_key' => 1,
      'filename' => 'modMediaSource/14ea878324b44a752e5be071c28de7b4.vehicle',
    ),
    433 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modDashboardWidget',
      'guid' => '8ad2b6d9af140d11deb449420700fb54',
      'native_key' => NULL,
      'filename' => 'modDashboardWidget/b39a244f819e83d6f8592a57d5551c6c.vehicle',
    ),
    434 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modDashboardWidget',
      'guid' => '9d5c04d8842e7ff1f7fbb893a27b457e',
      'native_key' => NULL,
      'filename' => 'modDashboardWidget/888e4549bf7551aa2de825e339a5b1bc.vehicle',
    ),
    435 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modDashboardWidget',
      'guid' => '794e253cad0a03df730db1e949261b95',
      'native_key' => NULL,
      'filename' => 'modDashboardWidget/052b1e0939bbad887915b2ed7574a2d4.vehicle',
    ),
    436 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modDashboardWidget',
      'guid' => 'b2fcd6f6e623bdb3c0133ea260741779',
      'native_key' => NULL,
      'filename' => 'modDashboardWidget/cdd789d76d4101ce7a3c38035b722ef1.vehicle',
    ),
    437 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modDashboardWidget',
      'guid' => 'f2fdedee7d8a356e7d546d655ac4e21d',
      'native_key' => NULL,
      'filename' => 'modDashboardWidget/222894f5254e8c0a8517975dc8942859.vehicle',
    ),
    438 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modUserGroupRole',
      'guid' => 'f72e7ea64573d6805152bc0dafdcdc8a',
      'native_key' => 1,
      'filename' => 'modUserGroupRole/5c2755b547542294b2e1c7e35d01edc1.vehicle',
    ),
    439 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modUserGroupRole',
      'guid' => 'd78dc7e85e7db10338f0b8cea7983989',
      'native_key' => 2,
      'filename' => 'modUserGroupRole/43e1f06174108768b6bd436f0e342b8a.vehicle',
    ),
    440 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplateGroup',
      'guid' => 'ceb1e8e786401669cd02beda047099dc',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplateGroup/03b24adb44aaee35af8d65df7b089a3e.vehicle',
    ),
    441 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplateGroup',
      'guid' => 'b454383f740a8eb29e09a5bf58a06804',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplateGroup/1b73361908525cd830d167cf0fe1342f.vehicle',
    ),
    442 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplateGroup',
      'guid' => 'bc5a52007ed8632685c7d549a25850f8',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplateGroup/903f788ebae6322b42dfb99f847847ba.vehicle',
    ),
    443 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplateGroup',
      'guid' => '0b8b78e46761cdf39ac25ac0b749a49f',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplateGroup/90fe868307d2efb5d8985a04bb00fd8a.vehicle',
    ),
    444 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplateGroup',
      'guid' => '03764453aab90d756f3278ffe54b588a',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplateGroup/7935fb0fe20fd2d7ac62bb95bddd5044.vehicle',
    ),
    445 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplateGroup',
      'guid' => '3687f9489f734b7557392dcbca454ad6',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplateGroup/99bb1ed8f40685d336d7548946168792.vehicle',
    ),
    446 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplate',
      'guid' => '0ba82aef05f2257c21f2b7d115d17664',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplate/5cee5e422c87209f6a0a68277f540185.vehicle',
    ),
    447 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplate',
      'guid' => 'be76caa0b1af7e05dfbf8210a7f60efa',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplate/1d311027f470b44d4dd763f7e29b36d7.vehicle',
    ),
    448 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplate',
      'guid' => 'f3d28adef92e33a440dea852d2809d46',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplate/51805e7ca67ea33deeab794b6cf39ef6.vehicle',
    ),
    449 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplate',
      'guid' => '3136b9517785abb61472bf51a48ce2f1',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplate/19b7461a98da15e5decc550c3832bad3.vehicle',
    ),
    450 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplate',
      'guid' => '3ba074ce52bfd91be200fec7eed1b6b5',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplate/cac47f85936902e00b09a6e76a618ae2.vehicle',
    ),
    451 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplate',
      'guid' => '9483689458649b5be30e6b0c41c5a3f6',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplate/3bcdced6e04d0a893af8a308d2d206c9.vehicle',
    ),
    452 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplate',
      'guid' => '835cfa635cade396692b1e6f9d89d7cb',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplate/016911eb51ed45c85ec144db66a1b9ef.vehicle',
    ),
    453 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicy',
      'guid' => '8c98f5d9534d7bc314615d7eb8fc1b17',
      'native_key' => 1,
      'filename' => 'modAccessPolicy/919cec5eda419eba4bee8be0f8b4c5c5.vehicle',
    ),
    454 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicy',
      'guid' => 'cbd3bc5766c65de380eab1d6a86330b9',
      'native_key' => 2,
      'filename' => 'modAccessPolicy/5c2b2640c010f7f041c1cd82c836fd2f.vehicle',
    ),
    455 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicy',
      'guid' => '4dd911d1f6c6da549c0d1e77ce75cc4e',
      'native_key' => 3,
      'filename' => 'modAccessPolicy/49153a001bef6de307fb934ccc37965d.vehicle',
    ),
    456 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicy',
      'guid' => '16de56ed43e5842f1b3cf073ac9eebca',
      'native_key' => 4,
      'filename' => 'modAccessPolicy/e31585be387cd0fbed032738f587739f.vehicle',
    ),
    457 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicy',
      'guid' => 'c739101aa93a9965916f2efffe1b6b37',
      'native_key' => 5,
      'filename' => 'modAccessPolicy/61b684b4e7666dd6e797271126913f7d.vehicle',
    ),
    458 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicy',
      'guid' => 'fa488e2d1dcda18f46efbab911f085cb',
      'native_key' => 6,
      'filename' => 'modAccessPolicy/2c3f3b73987e602698c6c48958130850.vehicle',
    ),
    459 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicy',
      'guid' => '62831215db7b3cfb62f7b28f83acb46e',
      'native_key' => 7,
      'filename' => 'modAccessPolicy/7d192786c398f6bc11bd7e18b1dc1c80.vehicle',
    ),
    460 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicy',
      'guid' => 'ac9e4f1987d8ee8fa978019c5058a391',
      'native_key' => 8,
      'filename' => 'modAccessPolicy/473e8c36933172e23b358f49c0e1138a.vehicle',
    ),
    461 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicy',
      'guid' => 'e7ebdf57515864dbfa78d1509abe4cdd',
      'native_key' => 9,
      'filename' => 'modAccessPolicy/ce515bbe989fcdda89c2f5fac8dc947a.vehicle',
    ),
    462 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicy',
      'guid' => 'd4648f48bba8f3c08bcc74bdd2454329',
      'native_key' => 10,
      'filename' => 'modAccessPolicy/5aa2ba34050e35c121d34b71807aa334.vehicle',
    ),
    463 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicy',
      'guid' => '1f35f70d5c56d28daff89991322768d3',
      'native_key' => 11,
      'filename' => 'modAccessPolicy/748ef9a2b0e4ee4cbf78efbaf638b390.vehicle',
    ),
    464 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicy',
      'guid' => 'a5089daf870961f4fa2cdc375e15f6d7',
      'native_key' => 12,
      'filename' => 'modAccessPolicy/bf6f6c616ac669ad2092ce81251ae588.vehicle',
    ),
    465 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modContext',
      'guid' => '70e4482144c498cbf0875b4e986e0eff',
      'native_key' => 'web',
      'filename' => 'modContext/19239d69c9c50bebd94dc28ba8402d0e.vehicle',
    ),
    466 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modContext',
      'guid' => '90ccfa9fffe394250290221e7e825c8f',
      'native_key' => 'mgr',
      'filename' => 'modContext/8205d70a717d3008cb46e1e687938c0b.vehicle',
    ),
    467 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOFileVehicle',
      'class' => 'xPDOFileVehicle',
      'guid' => '4b898f98b763fa5c8e8ab2bfc21472fb',
      'native_key' => '4b898f98b763fa5c8e8ab2bfc21472fb',
      'filename' => 'xPDOFileVehicle/0e2cbf86c2aa91fe432a066771b6bbf2.vehicle',
    ),
    468 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOFileVehicle',
      'class' => 'xPDOFileVehicle',
      'guid' => '94d1964b034e80f314ea74f3a13c5f8b',
      'native_key' => '94d1964b034e80f314ea74f3a13c5f8b',
      'filename' => 'xPDOFileVehicle/5a40af43af2dfb6e3ae8d6334d1aac70.vehicle',
    ),
    469 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOFileVehicle',
      'class' => 'xPDOFileVehicle',
      'guid' => 'e8724d29336144d5c8f52225f315cc06',
      'native_key' => 'e8724d29336144d5c8f52225f315cc06',
      'filename' => 'xPDOFileVehicle/24e0ada8a2f160c26adb6b3569cc12cd.vehicle',
    ),
    470 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOFileVehicle',
      'class' => 'xPDOFileVehicle',
      'guid' => '4a303faf9b55f433aab669f5845f9aed',
      'native_key' => '4a303faf9b55f433aab669f5845f9aed',
      'filename' => 'xPDOFileVehicle/ce01fc2814f8c65882ce4e8b1405f4bc.vehicle',
    ),
  ),
);